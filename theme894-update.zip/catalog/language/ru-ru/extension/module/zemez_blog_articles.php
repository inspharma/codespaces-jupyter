<?php

// Heading 
$_['heading_blog_title']        = 'Блог';

$_['text_date_format']     = 'd.m.Y';

$_['text_popular_all']     = 'Из блога';
$_['text_latest_all']      = 'Последнее в блоге';
$_['text_button_continue'] = 'Подробнее';
$_['text_comments']        = ' Комментарии';
$_['text_published']         = 'Опубликован ';
$_['text_posted']         = 'Отправлено ';
$_['text_by']         = '';

$_['text_no_result']       = 'Нет результатов!';

?>