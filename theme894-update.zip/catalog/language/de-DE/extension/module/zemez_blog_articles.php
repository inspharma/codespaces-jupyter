<?php

// Heading 
$_['heading_title']        = 'Blog';

$_['text_date_format']     = 'd.m.y';

$_['text_popular_all']     = 'Populäre Artikel';
$_['text_latest_all']      = 'Neueste Artikel';
$_['text_button_continue'] = 'Mehr lesen';
$_['text_comments']        = ' Kommentare';
$_['text_comment']         = ' Kommentar';



$_['text_no_result']       = 'Kein Ergebnis!';

?>