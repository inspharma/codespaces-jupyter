<?php
// Text
$_['text_information']  = 'Information';
$_['text_service']      = 'Kundenservice';
$_['text_extra']        = 'Extras';
$_['text_address']      = 'Adresse';
$_['text_contacts']      = 'Kontakte';
$_['text_return']       = 'Rückgabe';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacture'] = 'Marke';
$_['text_voucher']      = 'Geschenkgutscheine';
$_['text_affiliate']    = 'Verbundene Unternehmen';
$_['text_special']      = 'Besonderheiten';
$_['text_account']      = 'Mein Konto';
$_['text_order']        = 'Bestellhistorie';
$_['text_wishlist']     = 'Wunschliste';
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Unterstützt von <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
$_['text_telephone']    = 'Telefon';
$_['text_fax']          = 'Fax';
$_['text_email']        = 'e-mail:';
$_['text_catalog']      = 'Produktkatalog';
$_['text_lookbook']     = 'Lookbook';
$_['text_simple_blog']  = 'Blog';
$_['text_more']         = 'Mehr Einkaufsmöglichkeiten';
$_['text_store']        = 'Einen Shop finden';
$_['text_gift_cards']   = 'Geschenkkarten';
$_['text_wishlist']     = 'Wunschliste';