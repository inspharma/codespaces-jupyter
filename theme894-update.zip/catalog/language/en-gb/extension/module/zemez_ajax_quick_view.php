<?php
// Text

$_['text_manufacturer'] = 'Brand:';
$_['text_model']        = 'Model:';
$_['text_new']          = 'New';
$_['text_option']       = 'Available Options';
$_['text_quick']        = 'Quick View';
$_['text_sale']         = 'Sale';
$_['text_select']       = '--- Please Select ---';
$_['text_tax']          = 'Ex Tax:';
$_['entry_qty']         = 'QTY';
