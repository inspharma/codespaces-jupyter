<?php
// Text
$_['heading_title']     = 'Zemez Social List';