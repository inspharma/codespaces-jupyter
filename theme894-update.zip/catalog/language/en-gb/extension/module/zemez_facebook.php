<?php
// Heading
$_['heading_facebook_title']    = 'Facebook Box';

// Text
$_['text_edit']        = 'Edit Account';
