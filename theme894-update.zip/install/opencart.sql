SET SQL_MODE = '';
--
-- Структура таблицы `oc_banner`
--

DROP TABLE IF EXISTS `oc_banner`;
CREATE TABLE IF NOT EXISTS `oc_banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_banner`
--

INSERT INTO `oc_banner` (`banner_id`, `name`, `status`) VALUES
(16, 'Banners', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_banner_image`
--

DROP TABLE IF EXISTS `oc_banner_image`;
CREATE TABLE IF NOT EXISTS `oc_banner_image` (
  `banner_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `link` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `sort_order` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`banner_image_id`)
) ENGINE=MyISAM AUTO_INCREMENT=767 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_banner_image`
--

INSERT INTO `oc_banner_image` (`banner_image_id`, `banner_id`, `language_id`, `title`, `description`, `link`, `image`, `sort_order`) VALUES
(766, 16, 3, 'banner-2 background-secondary', '																		&lt;div&gt;\r\n&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;/i&gt;&lt;h3&gt;Free Shipping&lt;/h3&gt;\r\n&lt;h5&gt;on orders over $99.&lt;/h5&gt;\r\n&lt;p&gt;This offer is valid on all our store items.&lt;/p&gt;\r\n&lt;/div&gt; \r\n					 \r\n					 \r\n					', 'index.php?route=information/information&amp;information_id=6', 'catalog/banner-img.png', 2),
(765, 16, 3, 'banner-1', '&lt;div&gt;\r\n&lt;h4&gt;Special offer&lt;/h4&gt;\r\n&lt;h2&gt;10% OFF&lt;/h2&gt;\r\n&lt;h6&gt;When you use credit card&lt;/h6&gt;\r\n&lt;/div&gt; 			', 'index.php?route=product/special', 'catalog/banner-img.png', 1),
(763, 16, 4, 'banner-1', '&lt;div&gt;\r\n&lt;h4&gt;Special offer&lt;/h4&gt;\r\n&lt;h2&gt;10% OFF&lt;/h2&gt;\r\n&lt;h6&gt;When you use credit card&lt;/h6&gt;\r\n&lt;/div&gt; 			', 'index.php?route=product/special', 'catalog/banner-img.png', 1),
(764, 16, 4, 'banner-2 background-secondary', '																		&lt;div&gt;\r\n&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;/i&gt;&lt;h3&gt;Free Shipping&lt;/h3&gt;\r\n&lt;h5&gt;on orders over $99.&lt;/h5&gt;\r\n&lt;p&gt;This offer is valid on all our store items.&lt;/p&gt;\r\n&lt;/div&gt; \r\n					 \r\n					 \r\n					', 'index.php?route=information/information&amp;information_id=6', 'catalog/banner-img.png', 2),
(762, 16, 2, 'banner-2 background-secondary', '																		&lt;div&gt;\r\n&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;/i&gt;&lt;h3&gt;Free Shipping&lt;/h3&gt;\r\n&lt;h5&gt;on orders over $99.&lt;/h5&gt;\r\n&lt;p&gt;This offer is valid on all our store items.&lt;/p&gt;\r\n&lt;/div&gt; \r\n					 \r\n					 \r\n					', 'index.php?route=information/information&amp;information_id=6', 'catalog/banner-img.png', 2),
(761, 16, 2, 'banner-1', '&lt;div&gt;\r\n&lt;h4&gt;Special offer&lt;/h4&gt;\r\n&lt;h2&gt;10% OFF&lt;/h2&gt;\r\n&lt;h6&gt;When you use credit card&lt;/h6&gt;\r\n&lt;/div&gt; 			', 'index.php?route=product/special', 'catalog/banner-img.png', 1),
(759, 16, 1, 'banner-1', '&lt;div&gt;\r\n&lt;h4&gt;Special offer&lt;/h4&gt;\r\n&lt;h2&gt;10% OFF&lt;/h2&gt;\r\n&lt;h6&gt;When you use credit card&lt;/h6&gt;\r\n&lt;/div&gt; 			', 'index.php?route=product/special', 'catalog/banner-img.png', 1),
(760, 16, 1, 'banner-2 background-secondary', '&lt;div&gt;\r\n&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;/i&gt;&lt;h3&gt;Free Shipping&lt;/h3&gt;\r\n&lt;h5&gt;on orders over $99.&lt;/h5&gt;\r\n&lt;p&gt;This offer is valid on all our store items.&lt;/p&gt;\r\n&lt;/div&gt;	', 'index.php?route=information/information&amp;information_id=6', 'catalog/banner-img.png', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_extension`
--

DROP TABLE IF EXISTS `oc_extension`;
CREATE TABLE IF NOT EXISTS `oc_extension` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  PRIMARY KEY (`extension_id`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_extension`
--

INSERT INTO `oc_extension` (`extension_id`, `type`, `code`) VALUES
(1, 'payment', 'cod'),
(2, 'total', 'shipping'),
(3, 'total', 'sub_total'),
(4, 'total', 'tax'),
(5, 'total', 'total'),
(73, 'module', 'zemez_megamenu'),
(8, 'total', 'credit'),
(9, 'shipping', 'flat'),
(10, 'total', 'handling'),
(11, 'total', 'low_order_fee'),
(12, 'total', 'coupon'),
(15, 'total', 'reward'),
(16, 'total', 'voucher'),
(17, 'payment', 'free_checkout'),
(44, 'module', 'zemez_layout_builder'),
(92, 'module', 'zemez_blog_category'),
(21, 'dashboard', 'activity'),
(22, 'dashboard', 'sale'),
(23, 'dashboard', 'recent'),
(24, 'dashboard', 'order'),
(25, 'dashboard', 'online'),
(26, 'dashboard', 'map'),
(27, 'dashboard', 'customer'),
(28, 'dashboard', 'chart'),
(29, 'report', 'sale_coupon'),
(31, 'report', 'customer_search'),
(32, 'report', 'customer_transaction'),
(33, 'report', 'product_purchased'),
(34, 'report', 'product_viewed'),
(35, 'report', 'sale_return'),
(36, 'report', 'sale_order'),
(37, 'report', 'sale_shipping'),
(38, 'report', 'sale_tax'),
(39, 'report', 'customer_activity'),
(40, 'report', 'customer_order'),
(41, 'report', 'customer_reward'),
(56, 'module', 'zemez_google_map'),
(49, 'module', 'zemez_blog_articles'),
(50, 'module', 'latest'),
(100, 'module', 'featured'),
(52, 'module', 'zemez_footer_links'),
(54, 'module', 'banner'),
(59, 'module', 'filter'),
(60, 'module', 'special'),
(61, 'module', 'bestseller'),
(77, 'module', 'zemez_logo'),
(91, 'module', 'zemez_facebook'),
(102, 'module', 'zemez_newsletter_popup'),
(76, 'module', 'zemez_slideshow'),
(78, 'module', 'zemez_nav'),
(79, 'module', 'zemez_search'),
(83, 'module', 'zemez_cart'),
(81, 'module', 'zemez_currency'),
(82, 'module', 'zemez_language'),
(103, 'module', 'zemez_single_category_product'),
(89, 'module', 'zemez_pinterest'),
(90, 'module', 'zemez_twitter'),
(95, 'module', 'zemez_settings'),
(97, 'theme', 'zemez894'),
(106, 'module', 'zemez_wishlist'),
(107, 'module', 'html');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_extension_install`
--

DROP TABLE IF EXISTS `oc_extension_install`;
CREATE TABLE IF NOT EXISTS `oc_extension_install` (
  `extension_install_id` int(11) NOT NULL AUTO_INCREMENT,
  `extension_download_id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`extension_install_id`)
) ENGINE=MyISAM AUTO_INCREMENT=203 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_extension_install`
--

INSERT INTO `oc_extension_install` (`extension_install_id`, `extension_download_id`, `filename`, `date_added`) VALUES
(166, 0, 'ZEMEZ Megamenu.ocmod.zip', '2018-03-07 15:54:13'),
(63, 0, 'ZEMEZ Blog Articles.ocmod.zip', '2017-08-29 15:57:59'),
(169, 0, 'ZEMEZ Single Category Products.ocmod.zip', '2018-03-29 16:06:23'),
(147, 0, 'ZEMEZ Facebook.ocmod.zip', '2017-11-03 12:11:37'),
(170, 0, 'ZEMEZ Newsletter Popup.ocmod.zip', '2018-03-29 16:06:30'),
(134, 0, 'ZEMEZ Pinterest.ocmod.zip', '2017-10-30 15:29:47'),
(135, 0, 'ZEMEZ Twitter.ocmod.zip', '2017-10-30 15:29:51'),
(42, 0, 'zemez_product_hover.ocmod.zip', '2017-08-23 17:00:00'),
(138, 0, 'zemez_product.ocmod.zip', '2017-11-02 17:32:38'),
(178, 0, 'zemez_path_theme.ocmod.zip', '2018-04-05 16:09:11'),
(37, 0, 'zemez_page_direction.ocmod.zip', '2017-08-23 16:59:44'),
(153, 0, 'zemez_live_search.ocmod.zip', '2017-11-14 17:07:46'),
(35, 0, 'zemez_lazy_load.ocmod.zip', '2017-08-23 16:59:41'),
(129, 0, 'zemez_gtmetrix.ocmod.zip', '2017-10-27 12:52:10'),
(145, 0, 'zemez_footer.ocmod.zip', '2017-11-03 11:25:54'),
(30, 0, 'zemez_description_banner.ocmod.zip', '2017-08-23 16:59:31'),
(26, 0, 'zemez_blog_catalog.ocmod.zip', '2017-08-23 16:58:08'),
(43, 0, 'zemez_product_zoom.ocmod.zip', '2017-08-23 17:00:09'),
(44, 0, 'zemez_responsive.ocmod.zip', '2017-08-23 17:00:12'),
(202, 0, 'zemez_pages.ocmod.zip', '2018-10-12 18:46:30'),
(84, 0, 'zemez_ajax_add_to_cart.ocmod.zip', '2017-09-20 15:14:10'),
(199, 0, 'zemez_ajax_quickview.ocmod.zip', '2018-10-11 18:54:36'),
(197, 0, 'zemez_cart.ocmod.zip', '2018-10-11 16:35:31'),
(132, 0, 'zemez_positions.ocmod.zip', '2017-10-27 16:01:59'),
(128, 0, 'zemez_html.ocmod.zip', '2017-10-26 16:35:42'),
(123, 0, 'zemez_installer.ocmod.zip', '2017-10-26 12:38:40'),
(148, 0, 'zemez_product_timers.ocmod.zip', '2017-11-03 16:57:22'),
(137, 0, 'zemez_product-layout-type.ocmod.zip', '2017-10-31 14:24:01'),
(198, 0, 'zemez_header.ocmod.zip', '2018-10-11 16:35:35'),
(160, 0, 'zemez894_theme.ocmod.zip', '2017-11-24 11:58:14'),
(161, 0, 'zemez_labels.ocmod.zip', '2017-11-24 11:58:27'),
(167, 0, 'zemez_newsletter.ocmod.zip', '2018-03-29 16:05:50'),
(174, 0, 'ZEMEZ_Layout_Builder.ocmod.zip', '2018-04-04 18:48:33');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_extension_path`
--

DROP TABLE IF EXISTS `oc_extension_path`;
CREATE TABLE IF NOT EXISTS `oc_extension_path` (
  `extension_path_id` int(11) NOT NULL AUTO_INCREMENT,
  `extension_install_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`extension_path_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2624 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_extension_path`
--

INSERT INTO `oc_extension_path` (`extension_path_id`, `extension_install_id`, `path`, `date_added`) VALUES
(108, 26, 'catalog/view/theme/zemez/template/simple_blog/article.twig', '2017-08-23 16:58:09'),
(109, 26, 'catalog/view/theme/zemez/template/simple_blog/article_comment.twig', '2017-08-23 16:58:09'),
(106, 26, 'catalog/view/theme/default/template/simple_blog/article_comment.twig', '2017-08-23 16:58:09'),
(107, 26, 'catalog/view/theme/default/template/simple_blog/article_info.twig', '2017-08-23 16:58:09'),
(2465, 156, 'admin/view/template/extension/theme/zemez894.twig', '2017-11-16 18:46:11'),
(2466, 160, 'admin/controller/extension/theme/zemez894.php', '2017-11-24 11:58:15'),
(2467, 160, 'admin/language/en-gb/extension/theme/zemez894.php', '2017-11-24 11:58:15'),
(62, 26, 'admin/controller/simple_blog', '2017-08-23 16:58:09'),
(63, 26, 'admin/model/simple_blog', '2017-08-23 16:58:09'),
(64, 26, 'catalog/controller/simple_blog', '2017-08-23 16:58:09'),
(65, 26, 'catalog/model/simple_blog', '2017-08-23 16:58:09'),
(66, 26, 'admin/controller/simple_blog/article.php', '2017-08-23 16:58:09'),
(67, 26, 'admin/controller/simple_blog/author.php', '2017-08-23 16:58:09'),
(68, 26, 'admin/controller/simple_blog/category.php', '2017-08-23 16:58:09'),
(69, 26, 'admin/controller/simple_blog/comment.php', '2017-08-23 16:58:09'),
(70, 26, 'admin/controller/simple_blog/install.php', '2017-08-23 16:58:09'),
(71, 26, 'admin/controller/simple_blog/report.php', '2017-08-23 16:58:09'),
(72, 26, 'admin/language/en-gb/simple_blog', '2017-08-23 16:58:09'),
(73, 26, 'admin/model/simple_blog/article.php', '2017-08-23 16:58:09'),
(74, 26, 'admin/model/simple_blog/author.php', '2017-08-23 16:58:09'),
(75, 26, 'admin/model/simple_blog/category.php', '2017-08-23 16:58:09'),
(76, 26, 'admin/model/simple_blog/comment.php', '2017-08-23 16:58:09'),
(77, 26, 'admin/model/simple_blog/install.php', '2017-08-23 16:58:09'),
(78, 26, 'admin/model/simple_blog/report.php', '2017-08-23 16:58:09'),
(79, 26, 'admin/view/template/simple_blog', '2017-08-23 16:58:09'),
(80, 26, 'catalog/controller/simple_blog/article.php', '2017-08-23 16:58:09'),
(81, 26, 'catalog/controller/simple_blog/author.php', '2017-08-23 16:58:09'),
(82, 26, 'catalog/controller/simple_blog/category.php', '2017-08-23 16:58:09'),
(83, 26, 'catalog/controller/simple_blog/search.php', '2017-08-23 16:58:09'),
(84, 26, 'catalog/language/en-gb/simple_blog', '2017-08-23 16:58:09'),
(85, 26, 'catalog/model/simple_blog/article.php', '2017-08-23 16:58:09'),
(86, 26, 'admin/language/en-gb/simple_blog/article.php', '2017-08-23 16:58:09'),
(87, 26, 'admin/language/en-gb/simple_blog/author.php', '2017-08-23 16:58:09'),
(88, 26, 'admin/language/en-gb/simple_blog/category.php', '2017-08-23 16:58:09'),
(89, 26, 'admin/language/en-gb/simple_blog/comment.php', '2017-08-23 16:58:09'),
(90, 26, 'admin/language/en-gb/simple_blog/install.php', '2017-08-23 16:58:09'),
(91, 26, 'admin/language/en-gb/simple_blog/report.php', '2017-08-23 16:58:09'),
(92, 26, 'admin/view/template/simple_blog/article_form.twig', '2017-08-23 16:58:09'),
(93, 26, 'admin/view/template/simple_blog/article_list.twig', '2017-08-23 16:58:09'),
(94, 26, 'admin/view/template/simple_blog/author_form.twig', '2017-08-23 16:58:09'),
(95, 26, 'admin/view/template/simple_blog/author_list.twig', '2017-08-23 16:58:09'),
(96, 26, 'admin/view/template/simple_blog/category_form.twig', '2017-08-23 16:58:09'),
(97, 26, 'admin/view/template/simple_blog/category_list.twig', '2017-08-23 16:58:09'),
(98, 26, 'admin/view/template/simple_blog/comment_form.twig', '2017-08-23 16:58:09'),
(99, 26, 'admin/view/template/simple_blog/comment_list.twig', '2017-08-23 16:58:09'),
(100, 26, 'admin/view/template/simple_blog/notification.twig', '2017-08-23 16:58:09'),
(101, 26, 'admin/view/template/simple_blog/report.twig', '2017-08-23 16:58:09'),
(102, 26, 'catalog/language/en-gb/simple_blog/article.php', '2017-08-23 16:58:09'),
(103, 26, 'catalog/view/theme/default/template/simple_blog', '2017-08-23 16:58:09'),
(104, 26, 'catalog/view/theme/zemez/template/simple_blog', '2017-08-23 16:58:09'),
(105, 26, 'catalog/view/theme/default/template/simple_blog/article.twig', '2017-08-23 16:58:09'),
(110, 26, 'catalog/view/theme/zemez/template/simple_blog/article_info.twig', '2017-08-23 16:58:09'),
(111, 26, 'catalog/view/theme/default/template/extension/module/zemez_blog_articles.twig', '2017-08-23 16:58:09'),
(112, 26, 'catalog/view/theme/default/template/extension/module/zemez_blog_category.twig', '2017-08-23 16:58:09'),
(113, 26, 'catalog/view/theme/zemez/template/extension/module/zemez_blog_articles.twig', '2017-08-23 16:58:09'),
(114, 26, 'catalog/view/theme/zemez/template/extension/module/zemez_blog_category.twig', '2017-08-23 16:58:09'),
(2463, 156, 'admin/controller/extension/theme/zemez894.php', '2017-11-16 18:46:11'),
(2464, 156, 'admin/language/en-gb/extension/theme/zemez894.php', '2017-11-16 18:46:11'),
(2283, 132, 'catalog/view/theme/default/template/common/position.twig', '2017-10-27 16:02:00'),
(2284, 132, 'catalog/view/theme/zemez/template/common/position.twig', '2017-10-27 16:02:00'),
(2581, 174, 'admin/view/javascript/layout_builder', '2018-04-04 18:48:33'),
(2582, 174, 'admin/view/stylesheet/layout_builder', '2018-04-04 18:48:33'),
(2583, 174, 'admin/controller/extension/module/zemez_layout_builder.php', '2018-04-04 18:48:33'),
(2584, 174, 'admin/view/javascript/layout_builder/script.js', '2018-04-04 18:48:33'),
(2585, 174, 'admin/view/javascript/layout_builder/sortable.js', '2018-04-04 18:48:33'),
(2586, 174, 'admin/view/stylesheet/layout_builder/Edit_Notepad_Icon.svg.png', '2018-04-04 18:48:33'),
(2587, 174, 'admin/view/stylesheet/layout_builder/Trash_font_awesome.svg.png', '2018-04-04 18:48:33'),
(2588, 174, 'admin/view/stylesheet/layout_builder/grid_1200.png', '2018-04-04 18:48:33'),
(2589, 174, 'admin/view/stylesheet/layout_builder/grid_991.png', '2018-04-04 18:48:33'),
(2590, 174, 'admin/view/stylesheet/layout_builder/images', '2018-04-04 18:48:33'),
(2591, 174, 'admin/view/stylesheet/layout_builder/preload.gif', '2018-04-04 18:48:33'),
(2592, 174, 'admin/view/stylesheet/layout_builder/preload_old.gif', '2018-04-04 18:48:33'),
(2593, 174, 'admin/view/stylesheet/layout_builder/style.css', '2018-04-04 18:48:33'),
(2594, 174, 'catalog/controller/extension/module/zemez_layout_builder.php', '2018-04-04 18:48:33'),
(2595, 174, 'admin/language/en-gb/extension/module/zemez_layout_builder.php', '2018-04-04 18:48:33'),
(2596, 174, 'admin/view/stylesheet/layout_builder/images/add_column.png', '2018-04-04 18:48:33'),
(2597, 174, 'admin/view/stylesheet/layout_builder/images/add_row.gif', '2018-04-04 18:48:33'),
(2598, 174, 'admin/view/stylesheet/layout_builder/images/add_row.png', '2018-04-04 18:48:33'),
(2599, 174, 'admin/view/stylesheet/layout_builder/images/add_widget.png', '2018-04-04 18:48:33'),
(2600, 174, 'admin/view/stylesheet/layout_builder/images/bg-resize.png', '2018-04-04 18:48:33'),
(2601, 174, 'admin/view/stylesheet/layout_builder/images/bg.png', '2018-04-04 18:48:33'),
(2602, 174, 'admin/view/stylesheet/layout_builder/images/bg_hover.png', '2018-04-04 18:48:33'),
(2603, 174, 'admin/view/stylesheet/layout_builder/images/bg_hover.psd', '2018-04-04 18:48:33'),
(2604, 174, 'admin/view/stylesheet/layout_builder/images/close.png', '2018-04-04 18:48:33'),
(2605, 174, 'admin/view/stylesheet/layout_builder/images/col_add.png', '2018-04-04 18:48:33'),
(2606, 174, 'admin/view/stylesheet/layout_builder/images/col_config.png', '2018-04-04 18:48:33'),
(2607, 174, 'admin/view/stylesheet/layout_builder/images/col_delete.png', '2018-04-04 18:48:33'),
(2608, 174, 'admin/view/stylesheet/layout_builder/images/config.png', '2018-04-04 18:48:33'),
(2609, 174, 'admin/view/stylesheet/layout_builder/images/copy.png', '2018-04-04 18:48:33'),
(2610, 174, 'admin/view/stylesheet/layout_builder/images/drag.png', '2018-04-04 18:48:33'),
(2611, 174, 'admin/view/stylesheet/layout_builder/images/pattern.png', '2018-04-04 18:48:33'),
(2612, 174, 'admin/view/stylesheet/layout_builder/images/preload.gif', '2018-04-04 18:48:33'),
(2613, 174, 'admin/view/stylesheet/layout_builder/images/preload__.gif', '2018-04-04 18:48:33'),
(2614, 174, 'admin/view/stylesheet/layout_builder/images/remove_row.png', '2018-04-04 18:48:33'),
(2615, 174, 'admin/view/stylesheet/layout_builder/images/widget_copy.png', '2018-04-04 18:48:33'),
(2616, 174, 'admin/view/stylesheet/layout_builder/images/widget_del.png', '2018-04-04 18:48:33'),
(2617, 174, 'admin/view/stylesheet/layout_builder/images/widget_edit.png', '2018-04-04 18:48:33'),
(2481, 166, 'admin/controller/extension/module/zemez_megamenu.php', '2018-03-07 15:54:14'),
(2482, 166, 'catalog/controller/extension/module/zemez_megamenu.php', '2018-03-07 15:54:14'),
(2483, 166, 'catalog/model/extension/module/zemez_megamenu.php', '2018-03-07 15:54:14'),
(2484, 166, 'admin/language/en-gb/extension/module/zemez_megamenu.php', '2018-03-07 15:54:14'),
(2485, 166, 'admin/view/template/extension/module/zemez_megamenu.twig', '2018-03-07 15:54:14'),
(2486, 166, 'catalog/view/theme/zemez894/js/zemez_megamenu/jquery.rd-navbar.min.js', '2018-03-07 15:54:14'),
(2487, 166, 'catalog/view/theme/zemez894/js/zemez_megamenu/superfish.min.js', '2018-03-07 15:54:14'),
(2526, 170, 'admin/language/en-gb/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2527, 170, 'admin/language/ru-ru/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(1355, 63, 'admin/controller/extension/module/zemez_blog_articles.php', '2017-08-29 15:57:59'),
(1356, 63, 'catalog/controller/extension/module/zemez_blog_articles.php', '2017-08-29 15:57:59'),
(1357, 63, 'admin/view/template/extension/module/zemez_blog_articles.twig', '2017-08-29 15:57:59'),
(1358, 63, 'catalog/language/en-gb/extension/module/zemez_blog_articles.php', '2017-08-29 15:57:59'),
(1359, 63, 'catalog/language/ru-ru/extension/module/zemez_blog_articles.php', '2017-08-29 15:57:59'),
(1360, 63, 'catalog/view/theme/default/template/extension/module/zemez_blog_articles.twig', '2017-08-29 15:57:59'),
(2528, 170, 'admin/view/template/extension/module/zemez_newsletter_popup.twig', '2018-03-29 16:06:31'),
(2529, 170, 'catalog/language/de-DE/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2530, 170, 'catalog/language/en-gb/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2531, 170, 'catalog/language/ru-ru/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2532, 170, 'catalog/view/theme/default/template/extension/module/zemez_newsletter_popup.twig', '2018-03-29 16:06:31'),
(2533, 170, 'catalog/view/theme/zemez894/template/extension/module/zemez_newsletter_popup.twig', '2018-03-29 16:06:31'),
(2241, 120, 'admin/language/de-DE', '2017-10-26 10:32:42'),
(2242, 120, 'catalog/language/de-DE', '2017-10-26 10:32:42'),
(2243, 120, 'admin/language/de-DE/extension', '2017-10-26 10:32:42'),
(2244, 120, 'catalog/language/de-DE/extension', '2017-10-26 10:32:42'),
(2245, 120, 'admin/controller/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2246, 120, 'admin/language/de-DE/extension/module', '2017-10-26 10:32:42'),
(2247, 120, 'admin/model/extension/module/zemez_newsletter.php', '2017-10-26 10:32:42'),
(2248, 120, 'catalog/controller/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2249, 120, 'catalog/language/de-DE/extension/module', '2017-10-26 10:32:42'),
(2250, 120, 'catalog/model/extension/module/zemez_newsletter.php', '2017-10-26 10:32:42'),
(2251, 120, 'catalog/view/javascript/zemez/newsletter_popup', '2017-10-26 10:32:42'),
(2252, 120, 'admin/language/de-DE/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2253, 120, 'admin/language/en-gb/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2254, 120, 'admin/language/ru-ru/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2504, 169, 'catalog/language/de-DE', '2018-03-29 16:06:24'),
(2505, 169, 'catalog/language/de-DE/extension', '2018-03-29 16:06:24'),
(2506, 169, 'admin/controller/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2507, 169, 'catalog/controller/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2508, 169, 'catalog/language/de-DE/extension/module', '2018-03-29 16:06:24'),
(2509, 169, 'admin/language/en-gb/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2510, 169, 'admin/language/ru-ru/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2511, 169, 'admin/view/template/extension/module/zemez_single_category_product.twig', '2018-03-29 16:06:24'),
(2512, 169, 'catalog/language/ar/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2513, 169, 'catalog/language/de-DE/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2514, 169, 'catalog/language/en-gb/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2515, 169, 'catalog/language/ru-ru/extension/module/zemez_single_category_product.php', '2018-03-29 16:06:24'),
(2516, 169, 'catalog/view/theme/zemez894/js/zemez_single_category', '2018-03-29 16:06:24'),
(2517, 169, 'catalog/view/theme/zemez894/js/zemez_single_category/bootstrap-tabcollapse.js', '2018-03-29 16:06:24'),
(2518, 169, 'catalog/view/theme/default/template/extension/module/zemez_single_category_product.twig', '2018-03-29 16:06:24'),
(2519, 169, 'catalog/view/theme/zemez894/template/extension/module/zemez_single_category_product.twig', '2018-03-29 16:06:24'),
(2520, 170, 'admin/model/extension/module', '2018-03-29 16:06:31'),
(2521, 170, 'admin/controller/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2522, 170, 'admin/model/extension/module/zemez_newsletter.php', '2018-03-29 16:06:31'),
(2523, 170, 'catalog/controller/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2524, 170, 'catalog/model/extension/module/zemez_newsletter.php', '2018-03-29 16:06:31'),
(2525, 170, 'admin/language/de-DE/extension/module/zemez_newsletter_popup.php', '2018-03-29 16:06:31'),
(2183, 111, 'admin/controller/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2184, 111, 'catalog/controller/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2185, 111, 'admin/language/de-DE/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2186, 111, 'admin/language/en-gb/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2187, 111, 'admin/language/ru-ru/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2188, 111, 'admin/view/template/extension/module/zemez_instagram.twig', '2017-10-12 11:37:11'),
(2189, 111, 'catalog/language/de-DE/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2190, 111, 'catalog/language/en-gb/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2191, 111, 'catalog/language/ru-ru/extension/module/zemez_instagram.php', '2017-10-12 11:37:11'),
(2192, 111, 'catalog/view/theme/zemez/js/zemez_instagram', '2017-10-12 11:37:11'),
(2193, 111, 'catalog/view/theme/zemez/js/zemez_instagram/instafeed.min.js', '2017-10-12 11:37:11'),
(2194, 111, 'catalog/view/theme/default/template/extension/module/zemez_instagram.twig', '2017-10-12 11:37:11'),
(2195, 111, 'catalog/view/theme/zemez/template/extension/module/zemez_instagram.twig', '2017-10-12 11:37:11'),
(2488, 166, 'catalog/view/theme/default/template/extension/module/zemez_megamenu.twig', '2018-03-07 15:54:14'),
(2453, 147, 'admin/controller/extension/module/zemez_facebook.php', '2017-11-03 12:11:37'),
(2454, 147, 'catalog/controller/extension/module/zemez_facebook.php', '2017-11-03 12:11:37'),
(2455, 147, 'admin/language/en-gb/extension/module/zemez_facebook.php', '2017-11-03 12:11:37'),
(2456, 147, 'admin/view/template/extension/module/zemez_facebook.twig', '2017-11-03 12:11:37'),
(2457, 147, 'catalog/language/en-gb/extension/module/zemez_facebook.php', '2017-11-03 12:11:37'),
(2458, 147, 'catalog/view/theme/default/template/extension/module/zemez_facebook.twig', '2017-11-03 12:11:37'),
(2212, 117, 'admin/language/de-DE', '2017-10-23 19:10:41'),
(2213, 117, 'admin/language/de-DE/extension', '2017-10-23 19:10:41'),
(2214, 117, 'admin/controller/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2215, 117, 'admin/language/de-DE/extension/module', '2017-10-23 19:10:41'),
(2216, 117, 'catalog/controller/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2217, 117, 'catalog/model/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2218, 117, 'catalog/view/javascript/zemez/parallax', '2017-10-23 19:10:41'),
(2219, 117, 'admin/language/de-DE/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2220, 117, 'admin/language/en-gb/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2221, 117, 'admin/language/ru-ru/extension/module/zemez_parallax.php', '2017-10-23 19:10:41'),
(2222, 117, 'admin/view/template/extension/module/zemez_parallax.twig', '2017-10-23 19:10:41'),
(2223, 117, 'catalog/view/javascript/zemez/parallax/rd-parallax-min.js', '2017-10-23 19:10:41'),
(2224, 117, 'catalog/view/theme/default/template/extension/module/zemez_parallax.twig', '2017-10-23 19:10:41'),
(2225, 117, 'catalog/view/theme/zemez/template/extension/module/zemez_parallax.twig', '2017-10-23 19:10:41'),
(2226, 118, 'admin/language/de-DE', '2017-10-24 12:21:45'),
(2227, 118, 'admin/language/de-DE/extension', '2017-10-24 12:21:45'),
(2228, 118, 'admin/controller/extension/module/zemez_slideshow.php', '2017-10-24 12:21:45'),
(2229, 118, 'admin/language/de-DE/extension/module', '2017-10-24 12:21:45'),
(2230, 118, 'catalog/controller/extension/module/zemez_slideshow.php', '2017-10-24 12:21:45'),
(2231, 118, 'catalog/view/javascript/zemez/swiper', '2017-10-24 12:21:45'),
(2232, 118, 'admin/language/de-DE/extension/module/zemez_slideshow.php', '2017-10-24 12:21:45'),
(2233, 118, 'admin/language/en-gb/extension/module/zemez_slideshow.php', '2017-10-24 12:21:45'),
(2234, 118, 'admin/language/ru-ru/extension/module/zemez_slideshow.php', '2017-10-24 12:21:45'),
(2235, 118, 'admin/view/template/extension/module/zemez_slideshow.twig', '2017-10-24 12:21:45'),
(2236, 118, 'catalog/view/javascript/zemez/swiper/jquery.vide.min.js', '2017-10-24 12:21:45'),
(2237, 118, 'catalog/view/javascript/zemez/swiper/swinit.js', '2017-10-24 12:21:45'),
(2238, 118, 'catalog/view/javascript/zemez/swiper/swmin.js', '2017-10-24 12:21:45'),
(2239, 118, 'catalog/view/theme/default/template/extension/module/zemez_slideshow.twig', '2017-10-24 12:21:45'),
(2240, 118, 'catalog/view/theme/zemez/template/extension/module/zemez_slideshow.twig', '2017-10-24 12:21:45'),
(2255, 120, 'admin/view/template/extension/module/zemez_newsletter_popup.twig', '2017-10-26 10:32:42'),
(2256, 120, 'catalog/language/de-DE/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2257, 120, 'catalog/language/en-gb/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2258, 120, 'catalog/language/ru-ru/extension/module/zemez_newsletter_popup.php', '2017-10-26 10:32:42'),
(2259, 120, 'catalog/view/javascript/zemez/newsletter_popup/css', '2017-10-26 10:32:42'),
(2260, 120, 'catalog/view/javascript/zemez/newsletter_popup/css/newsletter_popup.css', '2017-10-26 10:32:42'),
(2261, 120, 'catalog/view/theme/default/template/extension/module/zemez_newsletter_popup.twig', '2017-10-26 10:32:42'),
(2262, 120, 'catalog/view/theme/zemez/template/extension/module/zemez_newsletter_popup.twig', '2017-10-26 10:32:42'),
(2285, 134, 'admin/controller/extension/module/zemez_pinterest.php', '2017-10-30 15:29:47'),
(2286, 134, 'catalog/controller/extension/module/zemez_pinterest.php', '2017-10-30 15:29:47'),
(2287, 134, 'admin/language/en-gb/extension/module/zemez_pinterest.php', '2017-10-30 15:29:47'),
(2288, 134, 'admin/view/template/extension/module/zemez_pinterest.twig', '2017-10-30 15:29:47'),
(2289, 134, 'catalog/language/en-gb/extension/module/zemez_pinterest.php', '2017-10-30 15:29:47'),
(2290, 134, 'catalog/view/theme/default/template/extension/module/zemez_pinterest.twig', '2017-10-30 15:29:47'),
(2291, 134, 'catalog/view/theme/zemez/template/extension/module/zemez_pinterest.twig', '2017-10-30 15:29:47'),
(2292, 135, 'admin/controller/extension/module/zemez_twitter.php', '2017-10-30 15:29:52'),
(2293, 135, 'admin/language/en-gb/extension/event.php', '2017-10-30 15:29:52'),
(2294, 135, 'admin/language/en-gb/extension/extension.php', '2017-10-30 15:29:52'),
(2295, 135, 'admin/language/en-gb/extension/installer.php', '2017-10-30 15:29:52'),
(2296, 135, 'admin/language/en-gb/extension/modification.php', '2017-10-30 15:29:52'),
(2297, 135, 'admin/language/en-gb/extension/openbay.php', '2017-10-30 15:29:52'),
(2298, 135, 'admin/language/en-gb/extension/store.php', '2017-10-30 15:29:52'),
(2299, 135, 'catalog/controller/extension/module/zemez_twitter.php', '2017-10-30 15:29:52'),
(2300, 135, 'admin/language/en-gb/extension/analytics/google_analytics.php', '2017-10-30 15:29:52'),
(2301, 135, 'admin/language/en-gb/extension/captcha/basic_captcha.php', '2017-10-30 15:29:52'),
(2302, 135, 'admin/language/en-gb/extension/captcha/google_captcha.php', '2017-10-30 15:29:52'),
(2303, 135, 'admin/language/en-gb/extension/dashboard/activity.php', '2017-10-30 15:29:52'),
(2304, 135, 'admin/language/en-gb/extension/dashboard/chart.php', '2017-10-30 15:29:52'),
(2305, 135, 'admin/language/en-gb/extension/dashboard/customer.php', '2017-10-30 15:29:52'),
(2306, 135, 'admin/language/en-gb/extension/dashboard/map.php', '2017-10-30 15:29:52'),
(2307, 135, 'admin/language/en-gb/extension/dashboard/online.php', '2017-10-30 15:29:52'),
(2308, 135, 'admin/language/en-gb/extension/dashboard/order.php', '2017-10-30 15:29:52'),
(2309, 135, 'admin/language/en-gb/extension/dashboard/recent.php', '2017-10-30 15:29:52'),
(2310, 135, 'admin/language/en-gb/extension/dashboard/sale.php', '2017-10-30 15:29:52'),
(2311, 135, 'admin/language/en-gb/extension/extension/analytics.php', '2017-10-30 15:29:52'),
(2312, 135, 'admin/language/en-gb/extension/extension/captcha.php', '2017-10-30 15:29:52'),
(2313, 135, 'admin/language/en-gb/extension/extension/dashboard.php', '2017-10-30 15:29:52'),
(2314, 135, 'admin/language/en-gb/extension/extension/feed.php', '2017-10-30 15:29:52'),
(2315, 135, 'admin/language/en-gb/extension/extension/fraud.php', '2017-10-30 15:29:52'),
(2316, 135, 'admin/language/en-gb/extension/extension/module.php', '2017-10-30 15:29:52'),
(2317, 135, 'admin/language/en-gb/extension/extension/openbay.php', '2017-10-30 15:29:52'),
(2318, 135, 'admin/language/en-gb/extension/extension/payment.php', '2017-10-30 15:29:52'),
(2319, 135, 'admin/language/en-gb/extension/extension/shipping.php', '2017-10-30 15:29:52'),
(2320, 135, 'admin/language/en-gb/extension/extension/theme.php', '2017-10-30 15:29:52'),
(2321, 135, 'admin/language/en-gb/extension/extension/total.php', '2017-10-30 15:29:52'),
(2322, 135, 'admin/language/en-gb/extension/feed/google_base.php', '2017-10-30 15:29:52'),
(2323, 135, 'admin/language/en-gb/extension/feed/google_sitemap.php', '2017-10-30 15:29:52'),
(2324, 135, 'admin/language/en-gb/extension/feed/openbaypro.php', '2017-10-30 15:29:52'),
(2325, 135, 'admin/language/en-gb/extension/fraud/fraudlabspro.php', '2017-10-30 15:29:52'),
(2326, 135, 'admin/language/en-gb/extension/fraud/ip.php', '2017-10-30 15:29:52'),
(2327, 135, 'admin/language/en-gb/extension/fraud/maxmind.php', '2017-10-30 15:29:52'),
(2328, 135, 'admin/language/en-gb/extension/module/zemez_twitter.php', '2017-10-30 15:29:52'),
(2329, 135, 'admin/language/en-gb/extension/openbay/amazon.php', '2017-10-30 15:29:52'),
(2330, 135, 'admin/language/en-gb/extension/openbay/amazon_bulk_linking.php', '2017-10-30 15:29:52'),
(2331, 135, 'admin/language/en-gb/extension/openbay/amazon_bulk_listing.php', '2017-10-30 15:29:52'),
(2332, 135, 'admin/language/en-gb/extension/openbay/amazon_links.php', '2017-10-30 15:29:52'),
(2333, 135, 'admin/language/en-gb/extension/openbay/amazon_listing.php', '2017-10-30 15:29:52'),
(2334, 135, 'admin/language/en-gb/extension/openbay/amazon_listingsaved.php', '2017-10-30 15:29:52'),
(2335, 135, 'admin/language/en-gb/extension/openbay/amazon_settings.php', '2017-10-30 15:29:52'),
(2336, 135, 'admin/language/en-gb/extension/openbay/amazon_stockupdates.php', '2017-10-30 15:29:52'),
(2337, 135, 'admin/language/en-gb/extension/openbay/amazon_subscription.php', '2017-10-30 15:29:52'),
(2338, 135, 'admin/language/en-gb/extension/openbay/amazonus.php', '2017-10-30 15:29:52'),
(2339, 135, 'admin/language/en-gb/extension/openbay/amazonus_bulk_linking.php', '2017-10-30 15:29:52'),
(2340, 135, 'admin/language/en-gb/extension/openbay/amazonus_bulk_listing.php', '2017-10-30 15:29:52'),
(2341, 135, 'admin/language/en-gb/extension/openbay/amazonus_links.php', '2017-10-30 15:29:52'),
(2342, 135, 'admin/language/en-gb/extension/openbay/amazonus_listing.php', '2017-10-30 15:29:52'),
(2343, 135, 'admin/language/en-gb/extension/openbay/amazonus_listingsaved.php', '2017-10-30 15:29:52'),
(2344, 135, 'admin/language/en-gb/extension/openbay/amazonus_settings.php', '2017-10-30 15:29:52'),
(2345, 135, 'admin/language/en-gb/extension/openbay/amazonus_stockupdates.php', '2017-10-30 15:29:52'),
(2346, 135, 'admin/language/en-gb/extension/openbay/amazonus_subscription.php', '2017-10-30 15:29:52'),
(2347, 135, 'admin/language/en-gb/extension/openbay/ebay.php', '2017-10-30 15:29:52'),
(2348, 135, 'admin/language/en-gb/extension/openbay/ebay_edit.php', '2017-10-30 15:29:52'),
(2349, 135, 'admin/language/en-gb/extension/openbay/ebay_import.php', '2017-10-30 15:29:52'),
(2350, 135, 'admin/language/en-gb/extension/openbay/ebay_links.php', '2017-10-30 15:29:52'),
(2351, 135, 'admin/language/en-gb/extension/openbay/ebay_new.php', '2017-10-30 15:29:52'),
(2352, 135, 'admin/language/en-gb/extension/openbay/ebay_newbulk.php', '2017-10-30 15:29:52'),
(2353, 135, 'admin/language/en-gb/extension/openbay/ebay_orders.php', '2017-10-30 15:29:52'),
(2354, 135, 'admin/language/en-gb/extension/openbay/ebay_profile.php', '2017-10-30 15:29:52'),
(2355, 135, 'admin/language/en-gb/extension/openbay/ebay_settings.php', '2017-10-30 15:29:52'),
(2356, 135, 'admin/language/en-gb/extension/openbay/ebay_subscription.php', '2017-10-30 15:29:52'),
(2357, 135, 'admin/language/en-gb/extension/openbay/ebay_summary.php', '2017-10-30 15:29:52'),
(2358, 135, 'admin/language/en-gb/extension/openbay/ebay_syncronise.php', '2017-10-30 15:29:52'),
(2359, 135, 'admin/language/en-gb/extension/openbay/ebay_template.php', '2017-10-30 15:29:52'),
(2360, 135, 'admin/language/en-gb/extension/openbay/ebay_usage.php', '2017-10-30 15:29:52'),
(2361, 135, 'admin/language/en-gb/extension/openbay/etsy.php', '2017-10-30 15:29:52'),
(2362, 135, 'admin/language/en-gb/extension/openbay/etsy_create.php', '2017-10-30 15:29:52'),
(2363, 135, 'admin/language/en-gb/extension/openbay/etsy_edit.php', '2017-10-30 15:29:52'),
(2364, 135, 'admin/language/en-gb/extension/openbay/etsy_links.php', '2017-10-30 15:29:52'),
(2365, 135, 'admin/language/en-gb/extension/openbay/etsy_listings.php', '2017-10-30 15:29:52'),
(2366, 135, 'admin/language/en-gb/extension/openbay/etsy_settings.php', '2017-10-30 15:29:52'),
(2367, 135, 'admin/language/en-gb/extension/openbay/fba.php', '2017-10-30 15:29:52'),
(2368, 135, 'admin/language/en-gb/extension/openbay/fba_fulfillment.php', '2017-10-30 15:29:52'),
(2369, 135, 'admin/language/en-gb/extension/openbay/fba_fulfillment_list.php', '2017-10-30 15:29:52'),
(2370, 135, 'admin/language/en-gb/extension/openbay/fba_order.php', '2017-10-30 15:29:52'),
(2371, 135, 'admin/language/en-gb/extension/openbay/fba_settings.php', '2017-10-30 15:29:52'),
(2372, 135, 'admin/language/en-gb/extension/openbay/openbay_itemlist.php', '2017-10-30 15:29:52'),
(2373, 135, 'admin/language/en-gb/extension/openbay/openbay_menu.php', '2017-10-30 15:29:52'),
(2374, 135, 'admin/language/en-gb/extension/openbay/openbay_order.php', '2017-10-30 15:29:52'),
(2375, 135, 'admin/language/en-gb/extension/payment/amazon_login_pay.php', '2017-10-30 15:29:52'),
(2376, 135, 'admin/language/en-gb/extension/payment/authorizenet_aim.php', '2017-10-30 15:29:52'),
(2377, 135, 'admin/language/en-gb/extension/payment/authorizenet_sim.php', '2017-10-30 15:29:52'),
(2378, 135, 'admin/language/en-gb/extension/payment/bank_transfer.php', '2017-10-30 15:29:52'),
(2379, 135, 'admin/language/en-gb/extension/payment/bluepay_hosted.php', '2017-10-30 15:29:52'),
(2380, 135, 'admin/language/en-gb/extension/payment/bluepay_redirect.php', '2017-10-30 15:29:52'),
(2381, 135, 'admin/language/en-gb/extension/payment/cardconnect.php', '2017-10-30 15:29:52'),
(2382, 135, 'admin/language/en-gb/extension/payment/cardinity.php', '2017-10-30 15:29:52'),
(2383, 135, 'admin/language/en-gb/extension/payment/cheque.php', '2017-10-30 15:29:52'),
(2384, 135, 'admin/language/en-gb/extension/payment/cod.php', '2017-10-30 15:29:52'),
(2385, 135, 'admin/language/en-gb/extension/payment/divido.php', '2017-10-30 15:29:52'),
(2386, 135, 'admin/language/en-gb/extension/payment/eway.php', '2017-10-30 15:29:52'),
(2387, 135, 'admin/language/en-gb/extension/payment/firstdata.php', '2017-10-30 15:29:52'),
(2388, 135, 'admin/language/en-gb/extension/payment/firstdata_remote.php', '2017-10-30 15:29:52'),
(2389, 135, 'admin/language/en-gb/extension/payment/free_checkout.php', '2017-10-30 15:29:52'),
(2390, 135, 'admin/language/en-gb/extension/payment/g2apay.php', '2017-10-30 15:29:52'),
(2391, 135, 'admin/language/en-gb/extension/payment/globalpay.php', '2017-10-30 15:29:52'),
(2392, 135, 'admin/language/en-gb/extension/payment/globalpay_remote.php', '2017-10-30 15:29:52'),
(2393, 135, 'admin/language/en-gb/extension/payment/klarna_account.php', '2017-10-30 15:29:52'),
(2394, 135, 'admin/language/en-gb/extension/payment/klarna_checkout.php', '2017-10-30 15:29:52'),
(2395, 135, 'admin/language/en-gb/extension/payment/klarna_invoice.php', '2017-10-30 15:29:52'),
(2396, 135, 'admin/language/en-gb/extension/payment/laybuy.php', '2017-10-30 15:29:52'),
(2397, 135, 'admin/language/en-gb/extension/payment/liqpay.php', '2017-10-30 15:29:52'),
(2398, 135, 'admin/language/en-gb/extension/payment/nochex.php', '2017-10-30 15:29:52'),
(2399, 135, 'admin/language/en-gb/extension/payment/paymate.php', '2017-10-30 15:29:52'),
(2400, 135, 'admin/language/en-gb/extension/payment/paypoint.php', '2017-10-30 15:29:52'),
(2401, 135, 'admin/language/en-gb/extension/payment/payza.php', '2017-10-30 15:29:52'),
(2402, 135, 'admin/language/en-gb/extension/payment/perpetual_payments.php', '2017-10-30 15:29:52'),
(2403, 135, 'admin/language/en-gb/extension/payment/pilibaba.php', '2017-10-30 15:29:52'),
(2404, 135, 'admin/language/en-gb/extension/payment/pp_express.php', '2017-10-30 15:29:52'),
(2405, 135, 'admin/language/en-gb/extension/payment/pp_express_order.php', '2017-10-30 15:29:52'),
(2406, 135, 'admin/language/en-gb/extension/payment/pp_express_refund.php', '2017-10-30 15:29:52'),
(2407, 135, 'admin/language/en-gb/extension/payment/pp_express_search.php', '2017-10-30 15:29:52'),
(2408, 135, 'admin/language/en-gb/extension/payment/pp_express_view.php', '2017-10-30 15:29:52'),
(2409, 135, 'admin/language/en-gb/extension/payment/pp_payflow.php', '2017-10-30 15:29:52'),
(2410, 135, 'admin/language/en-gb/extension/payment/pp_payflow_iframe.php', '2017-10-30 15:29:52'),
(2411, 135, 'admin/language/en-gb/extension/payment/pp_pro.php', '2017-10-30 15:29:52'),
(2412, 135, 'admin/language/en-gb/extension/payment/pp_pro_iframe.php', '2017-10-30 15:29:52'),
(2413, 135, 'admin/language/en-gb/extension/payment/pp_standard.php', '2017-10-30 15:29:52'),
(2414, 135, 'admin/language/en-gb/extension/payment/realex.php', '2017-10-30 15:29:53'),
(2415, 135, 'admin/language/en-gb/extension/payment/realex_remote.php', '2017-10-30 15:29:53'),
(2416, 135, 'admin/language/en-gb/extension/payment/sagepay_direct.php', '2017-10-30 15:29:53'),
(2417, 135, 'admin/language/en-gb/extension/payment/sagepay_server.php', '2017-10-30 15:29:53'),
(2418, 135, 'admin/language/en-gb/extension/payment/sagepay_us.php', '2017-10-30 15:29:53'),
(2419, 135, 'admin/language/en-gb/extension/payment/securetrading_pp.php', '2017-10-30 15:29:53'),
(2420, 135, 'admin/language/en-gb/extension/payment/securetrading_ws.php', '2017-10-30 15:29:53'),
(2421, 135, 'admin/language/en-gb/extension/payment/skrill.php', '2017-10-30 15:29:53'),
(2422, 135, 'admin/language/en-gb/extension/payment/twocheckout.php', '2017-10-30 15:29:53'),
(2423, 135, 'admin/language/en-gb/extension/payment/web_payment_software.php', '2017-10-30 15:29:53'),
(2424, 135, 'admin/language/en-gb/extension/payment/worldpay.php', '2017-10-30 15:29:53'),
(2425, 135, 'admin/language/en-gb/extension/shipping/auspost.php', '2017-10-30 15:29:53'),
(2426, 135, 'admin/language/en-gb/extension/shipping/citylink.php', '2017-10-30 15:29:53'),
(2427, 135, 'admin/language/en-gb/extension/shipping/fedex.php', '2017-10-30 15:29:53'),
(2428, 135, 'admin/language/en-gb/extension/shipping/flat.php', '2017-10-30 15:29:53'),
(2429, 135, 'admin/language/en-gb/extension/shipping/free.php', '2017-10-30 15:29:53'),
(2430, 135, 'admin/language/en-gb/extension/shipping/item.php', '2017-10-30 15:29:53'),
(2431, 135, 'admin/language/en-gb/extension/shipping/parcelforce_48.php', '2017-10-30 15:29:53'),
(2432, 135, 'admin/language/en-gb/extension/shipping/pickup.php', '2017-10-30 15:29:53'),
(2433, 135, 'admin/language/en-gb/extension/shipping/royal_mail.php', '2017-10-30 15:29:53'),
(2434, 135, 'admin/language/en-gb/extension/shipping/ups.php', '2017-10-30 15:29:53'),
(2435, 135, 'admin/language/en-gb/extension/shipping/usps.php', '2017-10-30 15:29:53'),
(2436, 135, 'admin/language/en-gb/extension/shipping/weight.php', '2017-10-30 15:29:53'),
(2437, 135, 'admin/language/en-gb/extension/theme/theme_default.php', '2017-10-30 15:29:53'),
(2438, 135, 'admin/language/en-gb/extension/total/coupon.php', '2017-10-30 15:29:53'),
(2439, 135, 'admin/language/en-gb/extension/total/credit.php', '2017-10-30 15:29:53'),
(2440, 135, 'admin/language/en-gb/extension/total/handling.php', '2017-10-30 15:29:53'),
(2441, 135, 'admin/language/en-gb/extension/total/klarna_fee.php', '2017-10-30 15:29:53'),
(2442, 135, 'admin/language/en-gb/extension/total/low_order_fee.php', '2017-10-30 15:29:53'),
(2443, 135, 'admin/language/en-gb/extension/total/reward.php', '2017-10-30 15:29:53'),
(2444, 135, 'admin/language/en-gb/extension/total/shipping.php', '2017-10-30 15:29:53'),
(2445, 135, 'admin/language/en-gb/extension/total/sub_total.php', '2017-10-30 15:29:53'),
(2446, 135, 'admin/language/en-gb/extension/total/tax.php', '2017-10-30 15:29:53'),
(2447, 135, 'admin/language/en-gb/extension/total/total.php', '2017-10-30 15:29:53'),
(2448, 135, 'admin/language/en-gb/extension/total/voucher.php', '2017-10-30 15:29:53'),
(2449, 135, 'admin/view/template/extension/module/zemez_twitter.twig', '2017-10-30 15:29:53'),
(2450, 135, 'catalog/language/en-gb/extension/module/zemez_twitter.php', '2017-10-30 15:29:53'),
(2451, 135, 'catalog/view/theme/default/template/extension/module/zemez_twitter.twig', '2017-10-30 15:29:53'),
(2452, 135, 'catalog/view/theme/zemez/template/extension/module/zemez_twitter.twig', '2017-10-30 15:29:53'),
(2459, 147, 'catalog/view/theme/zemez/template/extension/module/zemez_facebook.twig', '2017-11-03 12:11:37'),
(2468, 160, 'admin/view/template/extension/theme/zemez894.twig', '2017-11-24 11:58:15'),
(2489, 166, 'catalog/view/theme/zemez894/template/extension/module/zemez_megamenu.twig', '2018-03-07 15:54:14'),
(2618, 174, 'admin/view/template/extension/module/layout_builder', '2018-04-04 18:48:33'),
(2619, 174, 'catalog/view/theme/default/stylesheet/homebuilder.css', '2018-04-04 18:48:33'),
(2620, 174, 'admin/view/template/extension/module/layout_builder/modulestwig.twig', '2018-04-04 18:48:33'),
(2621, 174, 'admin/view/template/extension/module/layout_builder/ocmodulestwig.twig', '2018-04-04 18:48:33'),
(2622, 174, 'catalog/view/theme/default/template/extension/module/zemez_layout_builder.twig', '2018-04-04 18:48:33'),
(2623, 174, 'catalog/view/theme/zemez894/template/extension/module/zemez_layout_builder.twig', '2018-04-04 18:48:33');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_layout`
--

DROP TABLE IF EXISTS `oc_layout`;
CREATE TABLE IF NOT EXISTS `oc_layout` (
  `layout_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`layout_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_layout`
--

INSERT INTO `oc_layout` (`layout_id`, `name`) VALUES
(1, 'Home'),
(2, 'Product'),
(3, 'Category'),
(4, 'Default'),
(16, 'Manufacturer'),
(6, 'Account'),
(7, 'Checkout'),
(8, 'Contact'),
(9, 'Sitemap'),
(10, 'Affiliate'),
(11, 'Information'),
(12, 'Compare'),
(13, 'Search'),
(14, 'Blog'),
(15, 'Specials'),
(17, 'Manufacturer info');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_layout_module`
--

DROP TABLE IF EXISTS `oc_layout_module`;
CREATE TABLE IF NOT EXISTS `oc_layout_module` (
  `layout_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `layout_id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `position` varchar(14) NOT NULL,
  `sort_order` int(3) NOT NULL,
  PRIMARY KEY (`layout_module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1427 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_layout_module`
--

INSERT INTO `oc_layout_module` (`layout_module_id`, `layout_id`, `code`, `position`, `sort_order`) VALUES
(1391, 11, 'zemez_layout_builder.58', 'navigation', 0),
(1325, 16, 'zemez_layout_builder.67', 'footer_1', 1),
(1408, 13, 'latest.39', 'column_left', 0),
(1320, 3, 'zemez_layout_builder.67', 'footer_1', 1),
(1372, 14, 'zemez_blog_articles.96', 'column_left', 1),
(1386, 4, 'zemez_layout_builder.58', 'navigation', 0),
(1376, 7, 'zemez_layout_builder.58', 'navigation', 0),
(1381, 12, 'zemez_layout_builder.58', 'navigation', 0),
(1324, 16, 'zemez_megamenu.88', 'column_left', 0),
(1336, 15, 'bestseller.50', 'column_left', 1),
(1337, 15, 'latest.39', 'column_left', 2),
(1313, 1, 'zemez_newsletter_popup.121', 'content_top', 0),
(1312, 1, 'zemez_layout_builder.33', 'top', 2),
(1319, 3, 'filter', 'column_left', 1),
(1318, 3, 'zemez_megamenu.88', 'column_left', 0),
(1359, 6, 'zemez_layout_builder.58', 'navigation', 0),
(1358, 6, 'zemez_megamenu.88', 'header_top', 1),
(1357, 6, 'zemez_layout_builder.65', 'header_top', 0),
(1364, 10, 'zemez_layout_builder.58', 'navigation', 0),
(1363, 10, 'zemez_megamenu.88', 'header_top', 1),
(1362, 10, 'zemez_layout_builder.65', 'header_top', 0),
(1371, 14, 'zemez_blog_category.108', 'column_left', 0),
(1369, 14, 'zemez_layout_builder.58', 'navigation', 0),
(1375, 7, 'zemez_megamenu.88', 'header_top', 1),
(1374, 7, 'zemez_layout_builder.65', 'header_top', 0),
(1380, 12, 'zemez_megamenu.88', 'header_top', 1),
(1379, 12, 'zemez_layout_builder.65', 'header_top', 0),
(1425, 8, 'html.129', 'content_top', 0),
(1385, 4, 'zemez_megamenu.88', 'header_top', 1),
(1384, 4, 'zemez_layout_builder.65', 'header_top', 0),
(1390, 11, 'zemez_megamenu.88', 'header_top', 1),
(1389, 11, 'zemez_layout_builder.65', 'header_top', 0),
(1322, 16, 'zemez_layout_builder.58', 'navigation', 0),
(1321, 16, 'zemez_layout_builder.65', 'header_top', 0),
(1396, 17, 'zemez_layout_builder.58', 'navigation', 0),
(1395, 17, 'zemez_megamenu.88', 'header_top', 1),
(1394, 17, 'zemez_layout_builder.65', 'header_top', 0),
(1400, 2, 'zemez_megamenu.88', 'header_top', 1),
(1406, 13, 'zemez_layout_builder.58', 'navigation', 0),
(1405, 13, 'zemez_megamenu.88', 'header_top', 1),
(1404, 13, 'zemez_layout_builder.65', 'header_top', 0),
(1413, 9, 'zemez_layout_builder.58', 'navigation', 0),
(1412, 9, 'zemez_megamenu.88', 'header_top', 1),
(1411, 9, 'zemez_layout_builder.65', 'header_top', 0),
(1335, 15, 'zemez_megamenu.88', 'column_left', 0),
(1310, 1, 'zemez_layout_builder.58', 'navigation', 0),
(1426, 8, 'zemez_layout_builder.67', 'footer_1', 1),
(1423, 8, 'zemez_layout_builder.58', 'navigation', 0),
(1422, 8, 'zemez_megamenu.88', 'header_top', 1),
(1368, 14, 'zemez_megamenu.88', 'header_top', 1),
(1367, 14, 'zemez_layout_builder.65', 'header_top', 0),
(1309, 1, 'zemez_layout_builder.65', 'header_top', 0),
(1316, 3, 'zemez_layout_builder.58', 'navigation', 0),
(1315, 3, 'zemez_layout_builder.65', 'header_top', 0),
(1314, 1, 'zemez_layout_builder.67', 'footer_1', 1),
(1333, 15, 'zemez_layout_builder.58', 'navigation', 0),
(1332, 15, 'zemez_layout_builder.65', 'header_top', 0),
(1338, 15, 'zemez_layout_builder.67', 'footer_1', 1),
(1401, 2, 'zemez_layout_builder.58', 'navigation', 1),
(1399, 2, 'zemez_layout_builder.65', 'header_top', 0),
(1421, 8, 'zemez_layout_builder.65', 'header_top', 0),
(1361, 6, 'zemez_layout_builder.67', 'footer_1', 1),
(1366, 10, 'zemez_layout_builder.67', 'footer_1', 1),
(1373, 14, 'zemez_layout_builder.67', 'footer_1', 1),
(1378, 7, 'zemez_layout_builder.67', 'footer_1', 1),
(1383, 12, 'zemez_layout_builder.67', 'footer_1', 1),
(1388, 4, 'zemez_layout_builder.67', 'footer_1', 1),
(1393, 11, 'zemez_layout_builder.67', 'footer_1', 1),
(1398, 17, 'zemez_layout_builder.67', 'footer_1', 1),
(1403, 2, 'zemez_layout_builder.67', 'footer_1', 1),
(1409, 13, 'special.49', 'column_left', 1),
(1410, 13, 'zemez_layout_builder.67', 'footer_1', 1),
(1415, 9, 'zemez_layout_builder.67', 'footer_1', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_layout_route`
--

DROP TABLE IF EXISTS `oc_layout_route`;
CREATE TABLE IF NOT EXISTS `oc_layout_route` (
  `layout_route_id` int(11) NOT NULL AUTO_INCREMENT,
  `layout_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `route` varchar(64) NOT NULL,
  PRIMARY KEY (`layout_route_id`)
) ENGINE=MyISAM AUTO_INCREMENT=269 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_layout_route`
--

INSERT INTO `oc_layout_route` (`layout_route_id`, `layout_id`, `store_id`, `route`) VALUES
(256, 6, 0, 'account/%'),
(257, 10, 0, 'affiliate/%'),
(249, 3, 0, 'product/category'),
(248, 1, 0, 'common/home'),
(264, 2, 0, 'product/product'),
(262, 11, 0, 'information/information'),
(259, 7, 0, 'checkout/%'),
(268, 8, 0, 'information/contact'),
(266, 9, 0, 'information/sitemap'),
(261, 4, 0, ''),
(260, 12, 0, 'product/compare'),
(265, 13, 0, 'product/search'),
(252, 15, 0, 'product/special'),
(250, 16, 0, 'product/manufacturer/info'),
(258, 14, 0, 'simple_blog/article'),
(263, 17, 0, 'product/manufacturer/info');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_module`
--

DROP TABLE IF EXISTS `oc_module`;
CREATE TABLE IF NOT EXISTS `oc_module` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `code` varchar(32) NOT NULL,
  `setting` text NOT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=MyISAM AUTO_INCREMENT=130 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_module`
--

INSERT INTO `oc_module` (`module_id`, `name`, `code`, `setting`) VALUES
(33, 'Home Content', 'zemez_layout_builder', '{\"status\":\"1\",\"name\":\"Home Content\",\"class\":\"\",\"id\":\"\",\"layout\":\"[{\\\"index\\\":0,\\\"cls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"fullwidth\\\":0,\\\"parallax\\\":0,\\\"sfxcls\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"cols\\\":[{\\\"index\\\":0,\\\"cls\\\":\\\"column-left\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":3,\\\"mdcol\\\":3,\\\"smcol\\\":3,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Megamenu\\\",\\\"module\\\":\\\"zemez_megamenu.88\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]},{\\\"index\\\":0,\\\"cls\\\":\\\"column-content\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":9,\\\"mdcol\\\":9,\\\"smcol\\\":9,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Slideshow\\\",\\\"module\\\":\\\"zemez_slideshow.95\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"Banners\\\",\\\"module\\\":\\\"banner.82\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"Baby & Child Care\\\",\\\"module\\\":\\\"zemez_single_category_product.122\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]}]}]\"}'),
(129, 'Map info', 'html', '{\"name\":\"Map info\",\"class\":\"map-block\",\"module_description\":{\"1\":{\"title\":\"\",\"description\":\"&lt;iframe src=&quot;https:\\/\\/maps.google.com\\/maps?width=2050&amp;amp;height=386&amp;amp;hl=en&amp;amp;q=1%20Grafton%20Street%2C%20Dublin%2C%20Ireland+(My%20Business%20Name)&amp;amp;ie=UTF8&amp;amp;t=&amp;amp;z=15&amp;amp;iwloc=B&amp;amp;output=embed&quot; width=&quot;1170&quot; height=&quot;400&quot;&gt;&lt;\\/iframe&gt;\"},\"2\":{\"title\":\"\",\"description\":\"&lt;iframe src=&quot;https:\\/\\/maps.google.com\\/maps?width=2050&amp;amp;height=386&amp;amp;hl=en&amp;amp;q=1%20Grafton%20Street%2C%20Dublin%2C%20Ireland+(My%20Business%20Name)&amp;amp;ie=UTF8&amp;amp;t=&amp;amp;z=15&amp;amp;iwloc=B&amp;amp;output=embed&quot; width=&quot;1170&quot; height=&quot;400&quot;&gt;&lt;\\/iframe&gt;\"},\"4\":{\"title\":\"\",\"description\":\"&lt;iframe src=&quot;https:\\/\\/maps.google.com\\/maps?width=2050&amp;amp;height=386&amp;amp;hl=en&amp;amp;q=1%20Grafton%20Street%2C%20Dublin%2C%20Ireland+(My%20Business%20Name)&amp;amp;ie=UTF8&amp;amp;t=&amp;amp;z=15&amp;amp;iwloc=B&amp;amp;output=embed&quot; width=&quot;1170&quot; height=&quot;400&quot;&gt;&lt;\\/iframe&gt;\"},\"3\":{\"title\":\"\",\"description\":\"&lt;iframe src=&quot;https:\\/\\/maps.google.com\\/maps?width=2050&amp;amp;height=386&amp;amp;hl=en&amp;amp;q=1%20Grafton%20Street%2C%20Dublin%2C%20Ireland+(My%20Business%20Name)&amp;amp;ie=UTF8&amp;amp;t=&amp;amp;z=15&amp;amp;iwloc=B&amp;amp;output=embed&quot; width=&quot;1170&quot; height=&quot;400&quot;&gt;&lt;\\/iframe&gt;\"}},\"status\":\"1\"}'),
(124, 'Footer Links Servise', 'zemez_footer_links', '{\"name\":\"Footer Links Servise\",\"type\":\"1\",\"status\":\"1\"}'),
(67, 'Footer Accordion', 'zemez_layout_builder', '{\"status\":\"1\",\"name\":\"Footer Accordion\",\"class\":\"\",\"id\":\"\",\"layout\":\"[{\\\"cols\\\":[{\\\"index\\\":0,\\\"cls\\\":\\\"\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":4,\\\"mdcol\\\":4,\\\"smcol\\\":4,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Footer Links Servise\\\",\\\"module\\\":\\\"zemez_footer_links.124\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]},{\\\"index\\\":0,\\\"cls\\\":\\\"\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":4,\\\"mdcol\\\":4,\\\"smcol\\\":4,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Footer Links My account\\\",\\\"module\\\":\\\"zemez_footer_links.42\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]},{\\\"index\\\":0,\\\"cls\\\":\\\"\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":4,\\\"mdcol\\\":4,\\\"smcol\\\":4,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Footer Links Contact us\\\",\\\"module\\\":\\\"zemez_footer_links.43\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]}]}]\"}'),
(58, 'Header Top', 'zemez_layout_builder', '{\"status\":\"1\",\"name\":\"Header Top\",\"class\":\"\",\"id\":\"\",\"layout\":\"[{\\\"cols\\\":[{\\\"index\\\":0,\\\"cls\\\":\\\"container\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":12,\\\"mdcol\\\":12,\\\"smcol\\\":12,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"Logo\\\",\\\"module\\\":\\\"zemez_logo.97\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"ZEMEZ Cart\\\",\\\"module\\\":\\\"zemez_cart\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"ZEMEZ Wishlist\\\",\\\"module\\\":\\\"zemez_wishlist\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"ZEMEZ Search\\\",\\\"module\\\":\\\"zemez_search\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]}]},{\\\"cls\\\":\\\"menu-line\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"fullwidth\\\":\\\"1\\\",\\\"sfxcls\\\":null,\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":null,\\\"iattachment\\\":null,\\\"cols\\\":[{\\\"index\\\":0,\\\"cls\\\":\\\"container\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":12,\\\"mdcol\\\":12,\\\"smcol\\\":12,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"ZEMEZ Nav\\\",\\\"module\\\":\\\"zemez_nav\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]}]}]\"}'),
(65, 'Header Nav', 'zemez_layout_builder', '{\"status\":\"1\",\"name\":\"Header Nav\",\"class\":\"header-top\",\"id\":\"\",\"layout\":\"[{\\\"cols\\\":[{\\\"index\\\":0,\\\"cls\\\":\\\"container\\\",\\\"sfxcls\\\":\\\"\\\",\\\"bgcolor\\\":\\\"\\\",\\\"bgimage\\\":\\\"\\\",\\\"padding\\\":\\\"\\\",\\\"margin\\\":\\\"\\\",\\\"iposition\\\":\\\"\\\",\\\"iattachment\\\":\\\"\\\",\\\"inrow\\\":0,\\\"lgcol\\\":12,\\\"mdcol\\\":12,\\\"smcol\\\":12,\\\"xscol\\\":12,\\\"widgets\\\":[{\\\"name\\\":\\\"ZEMEZ Language\\\",\\\"module\\\":\\\"zemez_language\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"ZEMEZ Currency\\\",\\\"module\\\":\\\"zemez_currency\\\",\\\"tyle\\\":\\\"module\\\"},{\\\"name\\\":\\\"ZEMEZ Settings\\\",\\\"module\\\":\\\"zemez_settings\\\",\\\"tyle\\\":\\\"module\\\"}],\\\"rows\\\":[]}]}]\"}'),
(88, 'Megamenu', 'zemez_megamenu', '{\"name\":\"Megamenu\",\"status\":\"1\",\"menu_item\":[{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"1\",\"columns\":\"3\",\"columns-per-row\":\"3\",\"image\":\"catalog\\/menu-bg.jpg\",\"image_width\":\"887\",\"image_height\":\"420\",\"column\":[{\"width\":\"25%\",\"content\":\"2\",\"limit\":\"0\",\"prod_limit\":\"8\",\"module_id\":\"82\",\"category_id\":\"33\",\"category_show\":\"0\"},{\"width\":\"25%\",\"content\":\"2\",\"limit\":\"0\",\"prod_limit\":\"8\",\"module_id\":\"82\",\"category_id\":\"33\",\"category_show\":\"0\"},{\"width\":\"25%\",\"content\":\"2\",\"limit\":\"0\",\"prod_limit\":\"8\",\"module_id\":\"82\",\"category_id\":\"33\",\"category_show\":\"0\"}]},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"},{\"type\":\"0\",\"1\":{\"title\":\"\"},\"2\":{\"title\":\"\"},\"4\":{\"title\":\"\"},\"3\":{\"title\":\"\"},\"link\":\"\",\"submenu_show\":\"0\",\"submenu_type\":\"0\",\"columns\":\"0\",\"columns-per-row\":\"0\",\"image\":\"\",\"image_width\":\"\",\"image_height\":\"\"}]}'),
(47, 'Google Map', 'zemez_google_map', '{\"name\":\"Google Map\",\"zemez_google_map_key\":\"\",\"status\":\"1\",\"zemez_google_map_zoom\":\"14\",\"zemez_google_map_type\":\"1\",\"zemez_google_map_sensor\":\"true\",\"zemez_google_map_width\":\"100%\",\"zemez_google_map_height\":\"400px\",\"zemez_google_map_styles\":\"                                                                [{&quot;featureType&quot;:&quot;administrative&quot;,&quot;elementType&quot;:&quot;labels.text.fill&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#444444&quot;}]},{&quot;featureType&quot;:&quot;landscape&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#f2f2f2&quot;}]},{&quot;featureType&quot;:&quot;poi&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;road&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;saturation&quot;:-100},{&quot;lightness&quot;:45}]},{&quot;featureType&quot;:&quot;road.highway&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;simplified&quot;}]},{&quot;featureType&quot;:&quot;road.arterial&quot;,&quot;elementType&quot;:&quot;labels.icon&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;transit&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;visibility&quot;:&quot;off&quot;}]},{&quot;featureType&quot;:&quot;water&quot;,&quot;elementType&quot;:&quot;all&quot;,&quot;stylers&quot;:[{&quot;color&quot;:&quot;#46bcec&quot;},{&quot;visibility&quot;:&quot;on&quot;}]}]                                                        \",\"zemez_google_map_disable_ui\":\"false\",\"zemez_google_map_scrollwheel\":\"false\",\"zemez_google_map_draggable\":\"true\",\"zemez_google_map_marker\":\"catalog\\/marker_map.png\",\"zemez_google_map_marker_active\":\"catalog\\/marker_map_active.png\",\"zemez_google_map_marker_width\":\"40\",\"zemez_google_map_marker_height\":\"40\"}'),
(108, 'Blog Category', 'zemez_blog_category', '{\"status\":\"1\",\"name\":\"Blog Category\",\"category_search_article\":\"1\"}'),
(39, 'Latest Carousel Aside', 'latest', '{\"name\":\"Latest Carousel Aside\",\"layout_type\":\"1\",\"limit\":\"2\",\"width\":\"114\",\"height\":\"92\",\"status\":\"1\"}'),
(118, 'Featured Static Home', 'featured', '{\"name\":\"Featured Static Home\",\"layout_type\":\"0\",\"product_name\":\"\",\"product\":[\"33\",\"35\",\"48\",\"29\"],\"limit\":\"3\",\"width\":\"114\",\"height\":\"94\",\"status\":\"1\"}'),
(97, 'Logo', 'zemez_logo', '{\"name\":\"Logo\",\"width\":\"255\",\"height\":\"46\",\"status\":\"1\"}'),
(41, 'Footer Links Information', 'zemez_footer_links', '{\"name\":\"Footer Links Information\",\"type\":\"0\",\"status\":\"1\"}'),
(42, 'Footer Links My account', 'zemez_footer_links', '{\"name\":\"Footer Links My account\",\"type\":\"3\",\"status\":\"1\"}'),
(43, 'Footer Links Contact us', 'zemez_footer_links', '{\"name\":\"Footer Links Contact us\",\"type\":\"4\",\"status\":\"1\"}'),
(123, 'Footer Links Extras', 'zemez_footer_links', '{\"name\":\"Footer Links Extras\",\"type\":\"2\",\"status\":\"1\"}'),
(49, 'Specials Static Home', 'special', '{\"name\":\"Specials Static Home\",\"product_timers\":\"0\",\"layout_type\":\"0\",\"limit\":\"3\",\"width\":\"114\",\"height\":\"94\",\"status\":\"1\"}'),
(50, 'Bestsellers Carousel Aside', 'bestseller', '{\"name\":\"Bestsellers Carousel Aside\",\"layout_type\":\"1\",\"limit\":\"2\",\"width\":\"114\",\"height\":\"92\",\"status\":\"1\"}'),
(96, 'Popular Blog Articles', 'zemez_blog_articles', '{\"status\":\"1\",\"name\":\"Popular Blog Articles\",\"article_limit\":\"3\",\"show_readmore\":\"1\",\"show_date\":\"0\",\"show_author\":\"0\",\"show_comments\":\"0\",\"show_image\":\"1\",\"image_width\":\"228\",\"image_height\":\"160\",\"show_description\":\"1\",\"description_limit\":\"50\",\"category_id\":\"popular\"}'),
(82, 'Banners', 'banner', '{\"name\":\"Banners\",\"banner_id\":\"16\",\"width\":\"420\",\"height\":\"190\",\"status\":\"1\"}'),
(107, 'Facebook Box Contact', 'zemez_facebook', '{\"name\":\"Facebook Box Contact\",\"page_url\":\"https:\\/\\/www.facebook.com\\/zemezlab\\/\",\"app_id\":\"\",\"show_facepile\":\"true\",\"bg\":\"false\",\"show_posts\":\"true\",\"width\":\"370\",\"height\":\"410\",\"language\":\"en_US\",\"status\":\"1\"}'),
(121, 'Newsletter Popup', 'zemez_newsletter_popup', '{\"name\":\"Newsletter Popup\",\"newsletter_popup_bg\":\"catalog\\/newsletter-bg.jpg\",\"newsletter_popup_bg_width\":\"570\",\"newsletter_popup_bg_height\":\"371\",\"newsletter_popup_cookie\":\"0\",\"zemez_newsletter_popup_description\":{\"1\":{\"title\":\"Newsletter\",\"description\":\"Subscribe to the Drug Store mailing list to receive updates on new arrivals, special offers and other discount information.\"},\"2\":{\"title\":\"Newsletter\",\"description\":\"Subscribe to the Drug Store mailing list to receive updates on new arrivals, special offers and other discount information.\"},\"4\":{\"title\":\"Newsletter\",\"description\":\"Subscribe to the Drug Store mailing list to receive updates on new arrivals, special offers and other discount information.\"},\"3\":{\"title\":\"Newsletter\",\"description\":\"Subscribe to the Drug Store mailing list to receive updates on new arrivals, special offers and other discount information.\"}},\"status\":\"1\"}'),
(122, 'Baby &amp; Child Care', 'zemez_single_category_product', '{\"name\":\"Baby &amp; Child Care\",\"path\":\"Baby &amp; Child Care\",\"category\":\"33\",\"tabs\":\"1\",\"layout_type\":\"1\",\"type\":\"0\",\"special\":\"1\",\"bestseller\":\"0\",\"latest\":\"1\",\"featured\":\"1\",\"product\":[\"44\",\"28\",\"47\",\"30\",\"42\"],\"limit\":\"6\",\"width\":\"216\",\"height\":\"216\",\"status\":\"1\"}'),
(95, 'Slideshow', 'zemez_slideshow', '{\"name\":\"Slideshow\",\"status\":\"1\",\"width\":\"870\",\"height\":\"443\",\"min_height\":\"350\",\"effect\":\"1\",\"speed\":\"1200\",\"autoplay\":\"1\",\"keyboard_control\":\"0\",\"mousewheel_control\":\"0\",\"mousewheel_release_on_edges\":\"0\",\"next_button\":\"1\",\"prev_button\":\"1\",\"pagination\":\"0\",\"pagination_clickable\":\"1\",\"pagination_bullet_render\":\"0\",\"scrollbar\":\"0\",\"scrollbar_draggable\":\"0\",\"loop\":\"1\",\"slides\":[{\"slide_type\":\"0\",\"video_loop\":\"0\",\"video_autoplay\":\"0\",\"video_playback_rate\":\"\",\"video_muted\":\"1\",\"video_volume\":\"\",\"image\":\"catalog\\/slide-1.jpg\",\"title\":{\"1\":\"slide-1\",\"2\":\"slide-1\",\"4\":\"slide-1\",\"3\":\"slide-1\"},\"description\":{\"1\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 50%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Cosmetics&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"2\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 50%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Cosmetics&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"4\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 50%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Cosmetics&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"3\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 50%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Cosmetics&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\"},\"link\":\"index.php?route=product\\/product&amp;product_id=44\"},{\"slide_type\":\"0\",\"video_loop\":\"0\",\"video_autoplay\":\"0\",\"video_playback_rate\":\"\",\"video_muted\":\"1\",\"video_volume\":\"\",\"image\":\"catalog\\/slide-2.jpg\",\"title\":{\"1\":\"slide-2\",\"2\":\"slide-2\",\"4\":\"slide-2\",\"3\":\"slide-2\"},\"description\":{\"1\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;ON SKIN CARE PRODUCTS&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"2\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;ON SKIN CARE PRODUCTS&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"4\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;ON SKIN CARE PRODUCTS&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"3\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;ON SKIN CARE PRODUCTS&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\"},\"link\":\"index.php?route=product\\/product&amp;product_id=42\"},{\"slide_type\":\"0\",\"video_loop\":\"0\",\"video_autoplay\":\"0\",\"video_playback_rate\":\"\",\"video_muted\":\"1\",\"video_volume\":\"\",\"image\":\"catalog\\/slide-3.jpg\",\"title\":{\"1\":\"slide-3\",\"2\":\"slide-3\",\"4\":\"slide-3\",\"3\":\"slide-3\"},\"description\":{\"1\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description desc-black&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Diet &amp;amp; Nutrition&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"2\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description desc-black&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Diet &amp;amp; Nutrition&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"4\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description desc-black&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Diet &amp;amp; Nutrition&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\",\"3\":\"\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t&lt;div class=&quot;description desc-black&quot;&gt;\\r\\n&lt;h3&gt;Offer of The Week&lt;\\/h3&gt;\\r\\n&lt;h2&gt;Save 20%&lt;\\/h2&gt;\\r\\n&lt;h4&gt;Diet &amp;amp; Nutrition&lt;\\/h4&gt;\\r\\n&lt;\\/div&gt;\\r\\n\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\\t\"},\"link\":\"index.php?route=product\\/product&amp;product_id=34\"}]}'),
(105, 'Pinterest Contact', 'zemez_pinterest', '{\"name\":\"Pinterest Contact\",\"page_url\":\"https:\\/\\/www.pinterest.com\\/templatemonster\\/\",\"width\":\"340\",\"height\":\"300\",\"status\":\"1\"}'),
(106, 'Twitter Box Contact', 'zemez_twitter', '{\"name\":\"Twitter Box Contact\",\"page_url\":\"TemplateMonster\",\"widget_id\":\"955767218842849282\",\"tweet_limit\":\"\",\"color_scheme\":\"light\",\"width\":\"360\",\"height\":\"403\",\"status\":\"1\"}'),
(127, 'Natural Products', 'zemez_single_category_product', '{\"name\":\"Natural Products\",\"path\":\"Natural Products\",\"category\":\"39\",\"tabs\":\"1\",\"layout_type\":\"1\",\"type\":\"0\",\"special\":\"1\",\"bestseller\":\"0\",\"latest\":\"1\",\"featured\":\"1\",\"product\":[\"30\",\"41\",\"49\"],\"limit\":\"6\",\"width\":\"216\",\"height\":\"216\",\"status\":\"1\"}'),
(125, 'Facebook Box Home', 'zemez_facebook', '{\"name\":\"Facebook Box Home\",\"page_url\":\"https:\\/\\/www.facebook.com\\/zemezlab\\/\",\"app_id\":\"\",\"show_facepile\":\"true\",\"bg\":\"false\",\"show_posts\":\"true\",\"width\":\"270\",\"height\":\"215\",\"language\":\"en_US\",\"status\":\"1\"}'),
(126, 'Diet &amp; Nutrition', 'zemez_single_category_product', '{\"name\":\"Diet &amp; Nutrition\",\"path\":\"Diet &amp; Nutrition\",\"category\":\"20\",\"tabs\":\"1\",\"layout_type\":\"1\",\"type\":\"0\",\"special\":\"1\",\"bestseller\":\"0\",\"latest\":\"1\",\"featured\":\"1\",\"product\":[\"35\",\"33\",\"48\",\"44\",\"28\"],\"limit\":\"6\",\"width\":\"216\",\"height\":\"216\",\"status\":\"1\"}'),
(128, 'Info', 'html', '{\"name\":\"Info\",\"class\":\"info\",\"module_description\":{\"1\":{\"title\":\"\",\"description\":\"&lt;div class=&quot;row&quot;&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Fast &amp;amp; free delivery&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We understand that you need our products and we are committed to delivering your products quickly.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-lock&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Safe &amp;amp; secure payments&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We have providing online store with a variety of secure payment services.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=3&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-credit_card&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;100% money back gurantee&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;You may return or exchange your custom portrait up to five days from the date you received it.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n&lt;\\/div&gt;  \"},\"2\":{\"title\":\"\",\"description\":\"&lt;div class=&quot;row&quot;&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Fast &amp;amp; free delivery&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We understand that you need our products and we are committed to delivering your products quickly.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-lock&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Safe &amp;amp; secure payments&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We have providing online store with a variety of secure payment services.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=3&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-credit_card&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;100% money back gurantee&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;You may return or exchange your custom portrait up to five days from the date you received it.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n&lt;\\/div&gt;  \"},\"4\":{\"title\":\"\",\"description\":\"&lt;div class=&quot;row&quot;&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Fast &amp;amp; free delivery&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We understand that you need our products and we are committed to delivering your products quickly.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-lock&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Safe &amp;amp; secure payments&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We have providing online store with a variety of secure payment services.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=3&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-credit_card&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;100% money back gurantee&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;You may return or exchange your custom portrait up to five days from the date you received it.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n&lt;\\/div&gt;  \"},\"3\":{\"title\":\"\",\"description\":\"&lt;div class=&quot;row&quot;&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=6&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-local_shipping&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Fast &amp;amp; free delivery&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We understand that you need our products and we are committed to delivering your products quickly.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=5&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-lock&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;Safe &amp;amp; secure payments&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;We have providing online store with a variety of secure payment services.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n\\t&lt;div class=&quot;col-sm-4&quot;&gt;\\r\\n\\t\\t&lt;a href=&quot;index.php?route=information\\/information&amp;amp;information_id=3&quot;&gt;\\r\\n\\t\\t\\t&lt;i class=&quot;material-icons-credit_card&quot;&gt;&lt;\\/i&gt;&lt;h3&gt;100% money back gurantee&lt;\\/h3&gt;\\r\\n\\t\\t\\t&lt;p&gt;You may return or exchange your custom portrait up to five days from the date you received it.&lt;\\/p&gt;\\r\\n\\t\\t&lt;\\/a&gt;\\r\\n\\t&lt;\\/div&gt;\\r\\n&lt;\\/div&gt;  \"}},\"status\":\"1\"}');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_setting`
--

DROP TABLE IF EXISTS `oc_setting`;
CREATE TABLE IF NOT EXISTS `oc_setting` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `store_id` int(11) NOT NULL DEFAULT '0',
  `code` varchar(128) NOT NULL,
  `key` varchar(128) NOT NULL,
  `value` text NOT NULL,
  `serialized` tinyint(1) NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7057 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_setting`
--

INSERT INTO `oc_setting` (`setting_id`, `store_id`, `code`, `key`, `value`, `serialized`) VALUES
(4, 0, 'voucher', 'total_voucher_sort_order', '8', 0),
(5, 0, 'voucher', 'total_voucher_status', '1', 0),
(6808, 0, 'config', 'config_file_ext_allowed', 'zip\r\ntxt\r\npng\r\njpe\r\njpeg\r\njpg\r\ngif\r\nbmp\r\nico\r\ntiff\r\ntif\r\nsvg\r\nsvgz\r\nzip\r\nrar\r\nmsi\r\ncab\r\nmp3\r\nqt\r\nmov\r\npdf\r\npsd\r\nai\r\neps\r\nps\r\ndoc', 0),
(6807, 0, 'config', 'config_file_max_size', '300000', 0),
(6779, 0, 'config', 'config_affiliate_group_id', '1', 0),
(6780, 0, 'config', 'config_affiliate_approval', '0', 0),
(6781, 0, 'config', 'config_affiliate_auto', '0', 0),
(6782, 0, 'config', 'config_affiliate_commission', '5', 0),
(6783, 0, 'config', 'config_affiliate_id', '4', 0),
(6784, 0, 'config', 'config_return_id', '0', 0),
(6785, 0, 'config', 'config_return_status_id', '2', 0),
(6786, 0, 'config', 'config_captcha', '', 0),
(6787, 0, 'config', 'config_captcha_page', '[\"review\",\"return\",\"contact\"]', 1),
(6788, 0, 'config', 'config_logo', 'catalog/logo.png', 0),
(6789, 0, 'config', 'config_icon', 'catalog/favicon.png', 0),
(6790, 0, 'config', 'config_mail_engine', 'mail', 0),
(6791, 0, 'config', 'config_mail_parameter', '', 0),
(6792, 0, 'config', 'config_mail_smtp_hostname', '', 0),
(6793, 0, 'config', 'config_mail_smtp_username', '', 0),
(6794, 0, 'config', 'config_mail_smtp_password', '', 0),
(6795, 0, 'config', 'config_mail_smtp_port', '25', 0),
(6796, 0, 'config', 'config_mail_smtp_timeout', '5', 0),
(6797, 0, 'config', 'config_mail_alert', '[\"order\"]', 1),
(6798, 0, 'config', 'config_mail_alert_email', '', 0),
(6799, 0, 'config', 'config_maintenance', '0', 0),
(6800, 0, 'config', 'config_seo_url', '0', 0),
(6801, 0, 'config', 'config_robots', 'abot\r\ndbot\r\nebot\r\nhbot\r\nkbot\r\nlbot\r\nmbot\r\nnbot\r\nobot\r\npbot\r\nrbot\r\nsbot\r\ntbot\r\nvbot\r\nybot\r\nzbot\r\nbot.\r\nbot/\r\n_bot\r\n.bot\r\n/bot\r\n-bot\r\n:bot\r\n(bot\r\ncrawl\r\nslurp\r\nspider\r\nseek\r\naccoona\r\nacoon\r\nadressendeutschland\r\nah-ha.com\r\nahoy\r\naltavista\r\nananzi\r\nanthill\r\nappie\r\narachnophilia\r\narale\r\naraneo\r\naranha\r\narchitext\r\naretha\r\narks\r\nasterias\r\natlocal\r\natn\r\natomz\r\naugurfind\r\nbackrub\r\nbannana_bot\r\nbaypup\r\nbdfetch\r\nbig brother\r\nbiglotron\r\nbjaaland\r\nblackwidow\r\nblaiz\r\nblog\r\nblo.\r\nbloodhound\r\nboitho\r\nbooch\r\nbradley\r\nbutterfly\r\ncalif\r\ncassandra\r\nccubee\r\ncfetch\r\ncharlotte\r\nchurl\r\ncienciaficcion\r\ncmc\r\ncollective\r\ncomagent\r\ncombine\r\ncomputingsite\r\ncsci\r\ncurl\r\ncusco\r\ndaumoa\r\ndeepindex\r\ndelorie\r\ndepspid\r\ndeweb\r\ndie blinde kuh\r\ndigger\r\nditto\r\ndmoz\r\ndocomo\r\ndownload express\r\ndtaagent\r\ndwcp\r\nebiness\r\nebingbong\r\ne-collector\r\nejupiter\r\nemacs-w3 search engine\r\nesther\r\nevliya celebi\r\nezresult\r\nfalcon\r\nfelix ide\r\nferret\r\nfetchrover\r\nfido\r\nfindlinks\r\nfireball\r\nfish search\r\nfouineur\r\nfunnelweb\r\ngazz\r\ngcreep\r\ngenieknows\r\ngetterroboplus\r\ngeturl\r\nglx\r\ngoforit\r\ngolem\r\ngrabber\r\ngrapnel\r\ngralon\r\ngriffon\r\ngromit\r\ngrub\r\ngulliver\r\nhamahakki\r\nharvest\r\nhavindex\r\nhelix\r\nheritrix\r\nhku www octopus\r\nhomerweb\r\nhtdig\r\nhtml index\r\nhtml_analyzer\r\nhtmlgobble\r\nhubater\r\nhyper-decontextualizer\r\nia_archiver\r\nibm_planetwide\r\nichiro\r\niconsurf\r\niltrovatore\r\nimage.kapsi.net\r\nimagelock\r\nincywincy\r\nindexer\r\ninfobee\r\ninformant\r\ningrid\r\ninktomisearch.com\r\ninspector web\r\nintelliagent\r\ninternet shinchakubin\r\nip3000\r\niron33\r\nisraeli-search\r\nivia\r\njack\r\njakarta\r\njavabee\r\njetbot\r\njumpstation\r\nkatipo\r\nkdd-explorer\r\nkilroy\r\nknowledge\r\nkototoi\r\nkretrieve\r\nlabelgrabber\r\nlachesis\r\nlarbin\r\nlegs\r\nlibwww\r\nlinkalarm\r\nlink validator\r\nlinkscan\r\nlockon\r\nlwp\r\nlycos\r\nmagpie\r\nmantraagent\r\nmapoftheinternet\r\nmarvin/\r\nmattie\r\nmediafox\r\nmediapartners\r\nmercator\r\nmerzscope\r\nmicrosoft url control\r\nminirank\r\nmiva\r\nmj12\r\nmnogosearch\r\nmoget\r\nmonster\r\nmoose\r\nmotor\r\nmultitext\r\nmuncher\r\nmuscatferret\r\nmwd.search\r\nmyweb\r\nnajdi\r\nnameprotect\r\nnationaldirectory\r\nnazilla\r\nncsa beta\r\nnec-meshexplorer\r\nnederland.zoek\r\nnetcarta webmap engine\r\nnetmechanic\r\nnetresearchserver\r\nnetscoop\r\nnewscan-online\r\nnhse\r\nnokia6682/\r\nnomad\r\nnoyona\r\nnutch\r\nnzexplorer\r\nobjectssearch\r\noccam\r\nomni\r\nopen text\r\nopenfind\r\nopenintelligencedata\r\norb search\r\nosis-project\r\npack rat\r\npageboy\r\npagebull\r\npage_verifier\r\npanscient\r\nparasite\r\npartnersite\r\npatric\r\npear.\r\npegasus\r\nperegrinator\r\npgp key agent\r\nphantom\r\nphpdig\r\npicosearch\r\npiltdownman\r\npimptrain\r\npinpoint\r\npioneer\r\npiranha\r\nplumtreewebaccessor\r\npogodak\r\npoirot\r\npompos\r\npoppelsdorf\r\npoppi\r\npopular iconoclast\r\npsycheclone\r\npublisher\r\npython\r\nrambler\r\nraven search\r\nroach\r\nroad runner\r\nroadhouse\r\nrobbie\r\nrobofox\r\nrobozilla\r\nrules\r\nsalty\r\nsbider\r\nscooter\r\nscoutjet\r\nscrubby\r\nsearch.\r\nsearchprocess\r\nsemanticdiscovery\r\nsenrigan\r\nsg-scout\r\nshai\'hulud\r\nshark\r\nshopwiki\r\nsidewinder\r\nsift\r\nsilk\r\nsimmany\r\nsite searcher\r\nsite valet\r\nsitetech-rover\r\nskymob.com\r\nsleek\r\nsmartwit\r\nsna-\r\nsnappy\r\nsnooper\r\nsohu\r\nspeedfind\r\nsphere\r\nsphider\r\nspinner\r\nspyder\r\nsteeler/\r\nsuke\r\nsuntek\r\nsupersnooper\r\nsurfnomore\r\nsven\r\nsygol\r\nszukacz\r\ntach black widow\r\ntarantula\r\ntempleton\r\n/teoma\r\nt-h-u-n-d-e-r-s-t-o-n-e\r\ntheophrastus\r\ntitan\r\ntitin\r\ntkwww\r\ntoutatis\r\nt-rex\r\ntutorgig\r\ntwiceler\r\ntwisted\r\nucsd\r\nudmsearch\r\nurl check\r\nupdated\r\nvagabondo\r\nvalkyrie\r\nverticrawl\r\nvictoria\r\nvision-search\r\nvolcano\r\nvoyager/\r\nvoyager-hc\r\nw3c_validator\r\nw3m2\r\nw3mir\r\nwalker\r\nwallpaper\r\nwanderer\r\nwauuu\r\nwavefire\r\nweb core\r\nweb hopper\r\nweb wombat\r\nwebbandit\r\nwebcatcher\r\nwebcopy\r\nwebfoot\r\nweblayers\r\nweblinker\r\nweblog monitor\r\nwebmirror\r\nwebmonkey\r\nwebquest\r\nwebreaper\r\nwebsitepulse\r\nwebsnarf\r\nwebstolperer\r\nwebvac\r\nwebwalk\r\nwebwatch\r\nwebwombat\r\nwebzinger\r\nwhizbang\r\nwhowhere\r\nwild ferret\r\nworldlight\r\nwwwc\r\nwwwster\r\nxenu\r\nxget\r\nxift\r\nxirq\r\nyandex\r\nyanga\r\nyeti\r\nyodao\r\nzao\r\nzippp\r\nzyborg', 0),
(6802, 0, 'config', 'config_compression', '0', 0),
(6803, 0, 'config', 'config_secure', '0', 0),
(6804, 0, 'config', 'config_password', '1', 0),
(6805, 0, 'config', 'config_shared', '0', 0),
(7054, 0, 'config', 'config_encryption', 'xPNgBLweZCXdhOtlCAW4p9mrcEdQT4V0tXWIlNKJIMGYZyMvoFGQY4tqKZ747IazSZJY2RjZhcZNUffvUZv7LyZay6vLCtDC6iLhIIkEna3SxTQ4N8tdckSvp0y0fgUIfidgaKT0K780Gr25tDs57vEHgyfjGIcglqJ6ZPAO2NI4hIFLomXN5CamwVkDGEFqT05bMEvoaSvRkjw8JAoDP0xf3MBXjYtjrZurltGoEq7cdb5VVCrKdAvBsHK6HAkboy30fCwDvUcWYVxeLHr0bXNYbcbyFKTiYS6lXfYHcjgF4VHd6KxmyhdCvbLvfHGOuNONs7uXf9rJhipYN9ENK4GqvVflcZBaMq4Ys9vOIc4UGTJm4DgyvaWNnlcxPvpFRJwN5vLgiShij7RLfM0z8Wfk0z3QmmSsUKed0p1q1YdtBenNdOoSKFbnrbRGSVsFSmIHo6eUfMhRQd9pJYs50yk9MncGeHIXiV5ZXEOJhtxbyh1eP903xTv0xAXHke5fn9YnyNcQbbqy2OabQIdgb0TiRPAIRg0QDPAHUlrPKvSOaeJwAWGIUQ21X8Rg8era8pj8aHZQbgkySDKNNRMe18ay6r8adbIOaDAk1KRVvIq6lFJlEF3Xq4lyQhwV0Aqzkt0FhT4g97KSteiu5zvRFLcVDzsd6YeznYN50FumUL6iyNqmIlERpjFH1pCUwUQcXnZwILXfSpxHEkEAWokIlcoAqOnD865UlHF3WLnD8Zl1GIjkIqlTtyO10yloH2tgd6cIfr2RTzPXttOPt8e4KlEWfBA4JKIKZrv3JgFcLN1RarAoez1XXUEUvtSoqfwC3GzjMzgHVBqI09kyhVJdtNEI9SEzWbEQkSnbpQHjPPwdBZfH1NNA5CXEX95M4LWM74ziFVpFjnU4UBgtgHkaact7BtvsQqE5NTzEeNA2pfLjOWfegGh0ct9NX7GUnimuV4q3zkkRupIb3uaWTN68nn3ZVZOWKU9iPOTlfDbsa0ntBBRO6CHkHb8tyUplzuAs', 0),
(95, 0, 'payment_free_checkout', 'payment_free_checkout_status', '1', 0),
(96, 0, 'payment_free_checkout', 'free_checkout_order_status_id', '1', 0),
(97, 0, 'payment_free_checkout', 'payment_free_checkout_sort_order', '1', 0),
(98, 0, 'payment_cod', 'payment_cod_sort_order', '5', 0),
(99, 0, 'payment_cod', 'payment_cod_total', '0.01', 0),
(100, 0, 'payment_cod', 'payment_cod_order_status_id', '1', 0),
(101, 0, 'payment_cod', 'payment_cod_geo_zone_id', '0', 0),
(102, 0, 'payment_cod', 'payment_cod_status', '1', 0),
(103, 0, 'shipping_flat', 'shipping_flat_sort_order', '1', 0),
(104, 0, 'shipping_flat', 'shipping_flat_status', '1', 0),
(105, 0, 'shipping_flat', 'shipping_flat_geo_zone_id', '0', 0),
(106, 0, 'shipping_flat', 'shipping_flat_tax_class_id', '9', 0),
(107, 0, 'shipping_flat', 'shipping_flat_cost', '5.00', 0),
(108, 0, 'total_shipping', 'total_shipping_sort_order', '3', 0),
(109, 0, 'total_sub_total', 'sub_total_sort_order', '1', 0),
(110, 0, 'total_sub_total', 'total_sub_total_status', '1', 0),
(111, 0, 'total_tax', 'total_tax_status', '1', 0),
(112, 0, 'total_total', 'total_total_sort_order', '9', 0),
(113, 0, 'total_total', 'total_total_status', '1', 0),
(114, 0, 'total_tax', 'total_tax_sort_order', '5', 0),
(115, 0, 'total_credit', 'total_credit_sort_order', '7', 0),
(116, 0, 'total_credit', 'total_credit_status', '1', 0),
(117, 0, 'total_reward', 'total_reward_sort_order', '2', 0),
(118, 0, 'total_reward', 'total_reward_status', '1', 0),
(119, 0, 'total_shipping', 'total_shipping_status', '1', 0),
(120, 0, 'total_shipping', 'total_shipping_estimator', '1', 0),
(121, 0, 'total_coupon', 'total_coupon_sort_order', '4', 0),
(122, 0, 'total_coupon', 'total_coupon_status', '1', 0),
(149, 0, 'dashboard_activity', 'dashboard_activity_status', '1', 0),
(150, 0, 'dashboard_activity', 'dashboard_activity_sort_order', '7', 0),
(151, 0, 'dashboard_sale', 'dashboard_sale_status', '1', 0),
(152, 0, 'dashboard_sale', 'dashboard_sale_width', '3', 0),
(153, 0, 'dashboard_chart', 'dashboard_chart_status', '1', 0),
(154, 0, 'dashboard_chart', 'dashboard_chart_width', '6', 0),
(155, 0, 'dashboard_customer', 'dashboard_customer_status', '1', 0),
(156, 0, 'dashboard_customer', 'dashboard_customer_width', '3', 0),
(157, 0, 'dashboard_map', 'dashboard_map_status', '1', 0),
(158, 0, 'dashboard_map', 'dashboard_map_width', '6', 0),
(159, 0, 'dashboard_online', 'dashboard_online_status', '1', 0),
(160, 0, 'dashboard_online', 'dashboard_online_width', '3', 0),
(161, 0, 'dashboard_order', 'dashboard_order_sort_order', '1', 0),
(162, 0, 'dashboard_order', 'dashboard_order_status', '1', 0),
(163, 0, 'dashboard_order', 'dashboard_order_width', '3', 0),
(164, 0, 'dashboard_sale', 'dashboard_sale_sort_order', '2', 0),
(165, 0, 'dashboard_customer', 'dashboard_customer_sort_order', '3', 0),
(166, 0, 'dashboard_online', 'dashboard_online_sort_order', '4', 0),
(167, 0, 'dashboard_map', 'dashboard_map_sort_order', '5', 0),
(168, 0, 'dashboard_chart', 'dashboard_chart_sort_order', '6', 0),
(169, 0, 'dashboard_recent', 'dashboard_recent_status', '1', 0),
(170, 0, 'dashboard_recent', 'dashboard_recent_sort_order', '8', 0),
(171, 0, 'dashboard_activity', 'dashboard_activity_width', '4', 0),
(172, 0, 'dashboard_recent', 'dashboard_recent_width', '8', 0),
(173, 0, 'report_customer_activity', 'report_customer_activity_status', '1', 0),
(174, 0, 'report_customer_activity', 'report_customer_activity_sort_order', '1', 0),
(175, 0, 'report_customer_order', 'report_customer_order_status', '1', 0),
(176, 0, 'report_customer_order', 'report_customer_order_sort_order', '2', 0),
(177, 0, 'report_customer_reward', 'report_customer_reward_status', '1', 0),
(178, 0, 'report_customer_reward', 'report_customer_reward_sort_order', '3', 0),
(179, 0, 'report_customer_search', 'report_customer_search_sort_order', '3', 0),
(180, 0, 'report_customer_search', 'report_customer_search_status', '1', 0),
(181, 0, 'report_customer_transaction', 'report_customer_transaction_status', '1', 0),
(182, 0, 'report_customer_transaction', 'report_customer_transaction_status_sort_order', '4', 0),
(183, 0, 'report_sale_tax', 'report_sale_tax_status', '1', 0),
(184, 0, 'report_sale_tax', 'report_sale_tax_sort_order', '5', 0),
(185, 0, 'report_sale_shipping', 'report_sale_shipping_status', '1', 0),
(186, 0, 'report_sale_shipping', 'report_sale_shipping_sort_order', '6', 0),
(187, 0, 'report_sale_return', 'report_sale_return_status', '1', 0),
(188, 0, 'report_sale_return', 'report_sale_return_sort_order', '7', 0),
(189, 0, 'report_sale_order', 'report_sale_order_status', '1', 0),
(190, 0, 'report_sale_order', 'report_sale_order_sort_order', '8', 0),
(191, 0, 'report_sale_coupon', 'report_sale_coupon_status', '1', 0),
(192, 0, 'report_sale_coupon', 'report_sale_coupon_sort_order', '9', 0),
(193, 0, 'report_product_viewed', 'report_product_viewed_status', '1', 0),
(194, 0, 'report_product_viewed', 'report_product_viewed_sort_order', '10', 0),
(195, 0, 'report_product_purchased', 'report_product_purchased_status', '1', 0),
(196, 0, 'report_product_purchased', 'report_product_purchased_sort_order', '11', 0),
(197, 0, 'report_marketing', 'report_marketing_status', '1', 0),
(198, 0, 'report_marketing', 'report_marketing_sort_order', '12', 0),
(228, 0, 'developer', 'developer_theme', '0', 0),
(229, 0, 'developer', 'developer_sass', '1', 0),
(7052, 0, 'theme_zemez894', 'theme_zemez894_image_location_height', '46', 0),
(7051, 0, 'theme_zemez894', 'theme_zemez894_image_location_width', '255', 0),
(7050, 0, 'theme_zemez894', 'theme_zemez894_image_cart_height', '70', 0),
(7049, 0, 'theme_zemez894', 'theme_zemez894_image_cart_width', '70', 0),
(2138, 0, 'module_filter', 'module_filter_status', '1', 0),
(7048, 0, 'theme_zemez894', 'theme_zemez894_image_wishlist_height', '100', 0),
(7047, 0, 'theme_zemez894', 'theme_zemez894_image_wishlist_width', '100', 0),
(7046, 0, 'theme_zemez894', 'theme_zemez894_image_compare_height', '230', 0),
(3834, 0, 'zemez_nav', 'zemez_nav_status', '1', 0),
(3835, 0, 'zemez_language', 'zemez_language_status', '1', 0),
(3836, 0, 'zemez_currency', 'zemez_currency_status', '1', 0),
(3845, 0, 'zemez_cart', 'zemez_cart_status', '1', 0),
(3840, 0, 'zemez_search', 'zemez_search_status', '1', 0),
(3846, 0, 'module_zemez_cart', 'module_zemez_cart_status', '1', 0),
(3847, 0, 'module_zemez_currency', 'module_zemez_currency_status', '1', 0),
(3848, 0, 'module_zemez_language', 'module_zemez_language_status', '1', 0),
(3849, 0, 'module_zemez_search', 'module_zemez_search_status', '1', 0),
(4166, 0, 'zemez_settings', 'zemez_settings_status', '1', 0),
(6177, 0, 'module_zemez_nav', 'module_zemez_nav_status', '1', 0),
(6778, 0, 'config', 'config_stock_checkout', '0', 0),
(6777, 0, 'config', 'config_stock_warning', '0', 0),
(6776, 0, 'config', 'config_stock_display', '0', 0),
(7055, 0, 'config', 'config_api_id', '24', 0),
(6774, 0, 'config', 'config_fraud_status_id', '7', 0),
(6773, 0, 'config', 'config_complete_status', '[\"5\",\"3\"]', 1),
(6772, 0, 'config', 'config_processing_status', '[\"5\",\"1\",\"2\",\"12\",\"3\"]', 1),
(6771, 0, 'config', 'config_order_status_id', '1', 0),
(6770, 0, 'config', 'config_checkout_id', '5', 0),
(7045, 0, 'theme_zemez894', 'theme_zemez894_image_compare_width', '230', 0),
(7044, 0, 'theme_zemez894', 'theme_zemez894_image_related_height', '270', 0),
(7056, 0, 'module_zemez_settings', 'module_zemez_settings_status', '0', 0),
(6769, 0, 'config', 'config_checkout_guest', '1', 0),
(6768, 0, 'config', 'config_cart_weight', '1', 0),
(7043, 0, 'theme_zemez894', 'theme_zemez894_image_related_width', '270', 0),
(7042, 0, 'theme_zemez894', 'theme_zemez894_image_additional_height', '138', 0),
(7040, 0, 'theme_zemez894', 'theme_zemez894_image_product_height', '270', 0),
(7041, 0, 'theme_zemez894', 'theme_zemez894_image_additional_width', '138', 0),
(6767, 0, 'config', 'config_invoice_prefix', 'INV-2019-00', 0),
(7039, 0, 'theme_zemez894', 'theme_zemez894_image_product_width', '270', 0),
(7038, 0, 'theme_zemez894', 'theme_zemez894_image_popup_height', '800', 0),
(7037, 0, 'theme_zemez894', 'theme_zemez894_image_popup_width', '800', 0),
(6766, 0, 'config', 'config_account_id', '3', 0),
(6765, 0, 'config', 'config_login_attempts', '5', 0),
(6764, 0, 'config', 'config_customer_price', '0', 0),
(6763, 0, 'config', 'config_customer_group_display', '[\"1\"]', 1),
(6762, 0, 'config', 'config_customer_group_id', '1', 0),
(6761, 0, 'config', 'config_customer_search', '0', 0),
(6760, 0, 'config', 'config_customer_activity', '0', 0),
(6759, 0, 'config', 'config_customer_online', '0', 0),
(6758, 0, 'config', 'config_tax_customer', 'shipping', 0),
(6750, 0, 'config', 'config_product_count', '1', 0),
(6751, 0, 'config', 'config_limit_admin', '20', 0),
(6752, 0, 'config', 'config_review_status', '1', 0),
(6753, 0, 'config', 'config_review_guest', '1', 0),
(6754, 0, 'config', 'config_voucher_min', '1', 0),
(6755, 0, 'config', 'config_voucher_max', '1000', 0),
(6756, 0, 'config', 'config_tax', '0', 0),
(6757, 0, 'config', 'config_tax_default', 'shipping', 0),
(7036, 0, 'theme_zemez894', 'theme_zemez894_image_thumb_height', '500', 0),
(7035, 0, 'theme_zemez894', 'theme_zemez894_image_thumb_width', '518', 0),
(7034, 0, 'theme_zemez894', 'theme_zemez894_image_category_height', '170', 0),
(7033, 0, 'theme_zemez894', 'theme_zemez894_image_category_width', '170', 0),
(7032, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_share_social_site', '1', 0),
(7031, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_related_articles', '1', 0),
(7030, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_author_information', '1', 0),
(7029, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_comment_auto_approval', '0', 0),
(7028, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_description_limit', '100', 0),
(6176, 0, 'module_zemez_wishlist', 'module_zemez_wishlist_status', '1', 0),
(6749, 0, 'config', 'config_special_counters_title', '{\"1\":{\"days_title\":\"days\",\"hours_title\":\"hours\",\"minutes_title\":\"min\",\"seconds_title\":\"sec\"},\"2\":{\"days_title\":\"days\",\"hours_title\":\"hours\",\"minutes_title\":\"min\",\"seconds_title\":\"sec\"},\"4\":{\"days_title\":\"tage\",\"hours_title\":\"std\",\"minutes_title\":\"min\",\"seconds_title\":\"sec\"},\"3\":{\"days_title\":\"\\u0623\\u064a\\u0627\\u0645\",\"hours_title\":\"\\u0633\\u0627\\u0639\\u0627\\u062a\",\"minutes_title\":\"\\u062f\\u0642\\u064a\\u0642\\u0629\",\"seconds_title\":\"\\u062b\\u0648\\u0627\\u0646\\u064a\"}}', 1),
(6747, 0, 'config', 'config_weight_class_id', '1', 0),
(6748, 0, 'config', 'config_special_counters', '1', 0),
(6746, 0, 'config', 'config_length_class_id', '1', 0),
(6744, 0, 'config', 'config_currency', 'USD', 0),
(6745, 0, 'config', 'config_currency_auto', '1', 0),
(6743, 0, 'config', 'config_admin_language', 'en-gb', 0),
(6742, 0, 'config', 'config_language', 'en-gb', 0),
(6741, 0, 'config', 'config_zone_id', '3563', 0),
(7027, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_limit', '5', 0),
(7026, 0, 'theme_zemez894', 'theme_zemez894_simple_blog_status', '1', 0),
(7025, 0, 'theme_zemez894', 'theme_zemez894_product_description_length', '248', 0),
(7024, 0, 'theme_zemez894', 'theme_zemez894_product_limit', '6', 0),
(7023, 0, 'theme_zemez894', 'theme_zemez894_image_quickview_height', '1070', 0),
(7021, 0, 'theme_zemez894', 'theme_zemez894_product_zoom_type', '0', 0),
(6740, 0, 'config', 'config_country_id', '222', 0),
(7022, 0, 'theme_zemez894', 'theme_zemez894_image_quickview_width', '558', 0),
(7020, 0, 'theme_zemez894', 'theme_zemez894_label_new_limit', '6', 0),
(6809, 0, 'config', 'config_file_mime_allowed', 'text/plain\r\nimage/png\r\nimage/jpeg\r\nimage/gif\r\nimage/bmp\r\nimage/tiff\r\nimage/svg+xml\r\napplication/zip\r\n&quot;application/zip&quot;\r\napplication/x-zip\r\n&quot;application/x-zip&quot;\r\napplication/x-zip-compressed\r\n&quot;application/x-zip-compressed&quot;\r\napplication/rar\r\n&quot;application/rar&quot;\r\napplication/x-rar\r\n&quot;application/x-rar&quot;\r\napplication/x-rar-compressed\r\n&quot;application/x-rar-compressed&quot;\r\napplication/octet-stream\r\n&quot;application/octet-stream&quot;\r\naudio/mpeg\r\nvideo/quicktime\r\napplication/pdf', 0),
(6810, 0, 'config', 'config_error_display', '1', 0),
(6811, 0, 'config', 'config_error_log', '1', 0),
(6812, 0, 'config', 'config_error_filename', 'error.log', 0),
(7018, 0, 'theme_zemez894', 'theme_zemez894_label_discount', '1', 0),
(6739, 0, 'config', 'config_comment', 'We are glad to hear from you', 0),
(6737, 0, 'config', 'config_image', 'catalog/logo.png', 0),
(6738, 0, 'config', 'config_open', '7 days a week from 8:00 am to 5:00 pm', 0),
(6727, 0, 'config', 'config_meta_keyword', '', 0),
(6728, 0, 'config', 'config_theme', 'zemez894', 0),
(6729, 0, 'config', 'config_layout_id', '4', 0),
(6730, 0, 'config', 'config_name', 'Drug Store', 0),
(6731, 0, 'config', 'config_owner', 'Drug Store', 0),
(6732, 0, 'config', 'config_address', 'My Company Glasgow D04 89GR', 0),
(6733, 0, 'config', 'config_geocode', '40.6700, -73.9400', 0),
(7053, 0, 'config', 'config_email', 'admin@admin.com', 0),
(6735, 0, 'config', 'config_telephone', '800-2345-6789', 0),
(6736, 0, 'config', 'config_fax', '800-2345-6790', 0),
(6726, 0, 'config', 'config_meta_description', 'Drug Store', 0),
(6725, 0, 'config', 'config_meta_title', 'Drug Store', 0),
(7019, 0, 'theme_zemez894', 'theme_zemez894_label_new', '1', 0),
(7017, 0, 'theme_zemez894', 'theme_zemez894_label_sale', '0', 0),
(7016, 0, 'theme_zemez894', 'theme_zemez894_page_direction', 'ltr', 0),
(7015, 0, 'theme_zemez894', 'theme_zemez894_responsive', '0', 0),
(7014, 0, 'theme_zemez894', 'theme_zemez894_status', '1', 0),
(7013, 0, 'theme_zemez894', 'theme_zemez894_directory', 'zemez894', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article`
--

DROP TABLE IF EXISTS `oc_simple_blog_article`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article` (
  `simple_blog_article_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_author_id` int(16) NOT NULL,
  `allow_comment` tinyint(1) NOT NULL,
  `image` mediumtext NOT NULL,
  `featured_image` mediumtext NOT NULL,
  `article_related_method` varchar(64) NOT NULL,
  `article_related_option` mediumtext NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_article`
--

INSERT INTO `oc_simple_blog_article` (`simple_blog_article_id`, `simple_blog_author_id`, `allow_comment`, `image`, `featured_image`, `article_related_method`, `article_related_option`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(1, 1, 1, '', 'catalog/blog/post-1.jpg', 'product_wise', '', 0, 1, '2015-09-16 17:26:55', '2017-11-23 12:52:08'),
(2, 1, 1, '', 'catalog/blog/post-2.jpg', 'product_wise', '', 1, 1, '2015-09-17 10:25:42', '2017-11-23 12:51:51'),
(3, 2, 1, '', 'catalog/blog/post-3.jpg', 'category_wise', '', 2, 1, '2015-09-17 10:28:08', '2017-11-23 12:51:32'),
(4, 3, 1, '', 'catalog/blog/post-4.jpg', 'manufacturer_wise', '', 3, 1, '2015-09-21 16:51:28', '2017-11-23 12:51:17'),
(5, 3, 1, '', 'catalog/blog/post-5.jpg', 'category_wise', '', 4, 1, '2015-09-21 16:53:36', '2017-11-23 12:50:56'),
(6, 4, 1, '', 'catalog/blog/post-6.jpg', 'product_wise', '', 5, 1, '2015-09-21 16:55:11', '2017-11-23 12:50:38'),
(7, 4, 1, '', 'catalog/blog/post-7.jpg', 'product_wise', '', 6, 1, '2015-09-21 16:57:06', '2017-11-23 12:50:15'),
(8, 2, 1, '', 'catalog/blog/post-8.jpg', 'product_wise', '', 7, 1, '2015-09-21 16:59:22', '2018-03-01 15:16:55'),
(9, 3, 1, '', 'catalog/blog/post-9.jpg', 'product_wise', '', 8, 1, '2015-09-21 17:01:01', '2018-03-01 15:11:11'),
(10, 4, 1, '', 'catalog/blog/post-10.jpg', 'product_wise', '', 9, 1, '2015-10-13 15:07:26', '2018-03-01 15:09:19');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_description`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_description`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_description` (
  `simple_blog_article_description_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_article_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `article_title` varchar(256) NOT NULL,
  `description` mediumtext NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL,
  PRIMARY KEY (`simple_blog_article_description_id`)
) ENGINE=MyISAM AUTO_INCREMENT=407 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_article_description`
--

INSERT INTO `oc_simple_blog_article_description` (`simple_blog_article_description_id`, `simple_blog_article_id`, `language_id`, `article_title`, `description`, `meta_description`, `meta_keyword`) VALUES
(377, 2, 3, ' Believe in the Business of Your Dreams   ', '&lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won\'t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can\'t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don\'t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;   ', '   ', ''),
(369, 4, 3, ' Beautiful Rumi Quotes that are Worth Reading  ', '&lt;p&gt;Rumi, is the most popular Sufi poet in the world. His work is not only deep and intense, but also very ethereal. His poetry often stirs an emotion never touched and shows a facet never seen. This Buzzle article has a collection of some beautiful Rumi quotes that are worth reading, without which, life would literally feel quite disregarded.&lt;/p&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;As you start to walk on the way, the way appears.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Let yourself be silently drawn by the strange pull of what you really love. It will not lead you astray.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Two there are who are never satisfied -- the lover of the world and the lover of knowledge.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;What you seek is seeking you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t be satisfied with stories, how things have gone with others. Unfold your own myth.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Raise your words, not voice. It is rain that grows flowers, not thunder.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;You are not a drop in the ocean. You are the entire ocean in a drop.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Do you know what you are? You are a manuscript oƒ a divine letter. You are a mirror reflecting a noble face. This universe is not outside of you. Look inside yourself; everything that you want, you are already that.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t grieve. Anything you lose comes round in another form.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.&quot;\r\n&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Stop acting so small. You are the universe in ecstatic motion.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Forget safety. Live where you fear to live. Destroy your reputation. Be notorious.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Start a huge, foolish project, like Noah...it makes absolutely no difference what people think of you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;When you go through a hard period, when everything seems to oppose you, ... When you feel you cannot even bear one more minute, NEVER GIVE UP! Because it is the time and place that the course will divert!&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n\r\n  ', '  ', ''),
(361, 6, 3, ' Four Types of Verbal Communication  ', '&lt;p&gt;Verbal communication include sounds, words, language, and speech. Speaking is an effective way of communicating\r\n       and helps in expressing our emotions in words. This form of communication is further classified into four types,\r\n       which are:\r\n    &lt;/p&gt;\r\n    &lt;ol&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Intrapersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication is extremely private and restricted to ourselves. It includes the silent\r\n               conversations we have with ourselves, wherein we juggle roles between the sender and receiver who are\r\n               processing our thoughts and actions. This process of communication when analyzed can either be conveyed\r\n               verbally to someone or stay confined as thoughts.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Interpersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication takes place between two individuals and is thus a one-on-one conversation.\r\n               Here, the two individuals involved will swap their roles of sender and receiver in order to communicate\r\n               in a clearer manner.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Small Group Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication can take place only when there are more than two people involved. Here the\r\n               number of people will be small enough to allow each participant to interact and converse with the rest.\r\n               Press conferences, board meetings, and team meetings are examples of group communication. Unless a\r\n               specific issue is being discussed, small group discussions can become chaotic and difficult to interpret\r\n               by everybody. This lag in understanding information completely can result in miscommunication.\r\n            &lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Public Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication takes place when one individual addresses a large gathering of people.\r\n               Election campaigns and public speeches are example of this type of communication. In such cases, there is\r\n               usually a single sender of information and several receivers who are being addressed.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n    &lt;/ol&gt;  ', '  ', ''),
(360, 6, 2, 'Four Types of Verbal Communication  ', '&lt;p&gt;Verbal communication include sounds, words, language, and speech. Speaking is an effective way of communicating\r\n       and helps in expressing our emotions in words. This form of communication is further classified into four types,\r\n       which are:\r\n    &lt;/p&gt;\r\n    &lt;ol&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Intrapersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication is extremely private and restricted to ourselves. It includes the silent\r\n               conversations we have with ourselves, wherein we juggle roles between the sender and receiver who are\r\n               processing our thoughts and actions. This process of communication when analyzed can either be conveyed\r\n               verbally to someone or stay confined as thoughts.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Interpersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication takes place between two individuals and is thus a one-on-one conversation.\r\n               Here, the two individuals involved will swap their roles of sender and receiver in order to communicate\r\n               in a clearer manner.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Small Group Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication can take place only when there are more than two people involved. Here the\r\n               number of people will be small enough to allow each participant to interact and converse with the rest.\r\n               Press conferences, board meetings, and team meetings are examples of group communication. Unless a\r\n               specific issue is being discussed, small group discussions can become chaotic and difficult to interpret\r\n               by everybody. This lag in understanding information completely can result in miscommunication.\r\n            &lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Public Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication takes place when one individual addresses a large gathering of people.\r\n               Election campaigns and public speeches are example of this type of communication. In such cases, there is\r\n               usually a single sender of information and several receivers who are being addressed.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n    &lt;/ol&gt;  ', '  ', ''),
(373, 3, 3, ' Impact - The Heart of Business  ', '&lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;  ', '  ', ''),
(372, 3, 2, 'Impact - The Heart of Business  ', '&lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;  ', '  ', ''),
(357, 7, 3, ' Proper color solutions for the office  ', '&lt;p&gt;When it comes to remodeling an office, one of the most important aspects is painting. Any shade of paint can\r\n       change the complete look of a room as a color has an ability to change a drab and boring room into a stunning\r\n       one. Many people prefer to paint their homes in serene colors as it relaxes the mind. There are many hues of\r\n       colors to choose from that match the atmosphere of a room.&lt;/p&gt;\r\n\r\n    &lt;p&gt;An office is a place where many people come and go. Choose some paint colors that will stimulate the employees,\r\n       relax the customers and make them feel welcome. Here are some ideas for interior paint colors and combinations to\r\n       remodel your office and make it look more appealing to the vision.&lt;/p&gt;\r\n\r\n    &lt;p&gt;Avoid using white, as this color gives a very sterile look to the walls. Remember a shade of color can make a\r\n       room look large or small. So, it is better to avoid black or dark colors that will give off a repulsive look to\r\n       your office.&lt;/p&gt;\r\n\r\n    &lt;p&gt;The popular choice of paint colors that will give a soothing and inviting look to your office are beige, tan,\r\n       light yellow and some shades of blue.&lt;/p&gt;\r\n\r\n    &lt;p&gt;When you choose paint colors for your office make sure that these colors have a resemblance to the flooring and\r\n       office furniture.&lt;/p&gt;\r\n\r\n    &lt;p&gt;These were some tips for choosing paint colors. Before you paint the walls of the room, always paint a small\r\n       portion of the wall to check how it looks. If you are satisfied with the result, you can go ahead with the task,\r\n       or else you can always try other combinations. Whatever color you choose, make sure that it serves its purpose\r\n       and brightens up the atmosphere of the room. Happy painting!&lt;/p&gt;  ', '  ', ''),
(356, 7, 2, 'Proper color solutions for the office  ', '&lt;p&gt;When it comes to remodeling an office, one of the most important aspects is painting. Any shade of paint can\r\n       change the complete look of a room as a color has an ability to change a drab and boring room into a stunning\r\n       one. Many people prefer to paint their homes in serene colors as it relaxes the mind. There are many hues of\r\n       colors to choose from that match the atmosphere of a room.&lt;/p&gt;\r\n\r\n    &lt;p&gt;An office is a place where many people come and go. Choose some paint colors that will stimulate the employees,\r\n       relax the customers and make them feel welcome. Here are some ideas for interior paint colors and combinations to\r\n       remodel your office and make it look more appealing to the vision.&lt;/p&gt;\r\n\r\n    &lt;p&gt;Avoid using white, as this color gives a very sterile look to the walls. Remember a shade of color can make a\r\n       room look large or small. So, it is better to avoid black or dark colors that will give off a repulsive look to\r\n       your office.&lt;/p&gt;\r\n\r\n    &lt;p&gt;The popular choice of paint colors that will give a soothing and inviting look to your office are beige, tan,\r\n       light yellow and some shades of blue.&lt;/p&gt;\r\n\r\n    &lt;p&gt;When you choose paint colors for your office make sure that these colors have a resemblance to the flooring and\r\n       office furniture.&lt;/p&gt;\r\n\r\n    &lt;p&gt;These were some tips for choosing paint colors. Before you paint the walls of the room, always paint a small\r\n       portion of the wall to check how it looks. If you are satisfied with the result, you can go ahead with the task,\r\n       or else you can always try other combinations. Whatever color you choose, make sure that it serves its purpose\r\n       and brightens up the atmosphere of the room. Happy painting!&lt;/p&gt;  ', '  ', ''),
(365, 5, 3, ' How to Keep Your Heart Healthy  ', '&lt;p&gt;So how to keep your heart healthy? With so many heart diseases on the rise, most health-conscious people strive\r\n       to\r\n       seek the answer to this question. This article attempts to help you find the answer.&lt;/p&gt;\r\n    &lt;h5&gt;Go Green&lt;/h5&gt;\r\n\r\n    &lt;p&gt;When we speak of heart, we cannot miss out on the importance and benefits of plant foods. Vegetables are an\r\n       excellent source of glutamic acid. It is a class of amino acid which helps keeping blood pressure at lower\r\n       levels; safe levels, so to say. What\'s more? Veggies lack cholesterol, fat and even calories, which otherwise\r\n       tend to be the common culprits for causing heart diseases. Not to mention, the amount of vitamins and minerals\r\n       that vegetables provide to the body do the most for health.\r\n\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Be Active&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Without the aid of daily exercise, maintaining a good overall health is just more than a daunting task. Exercises\r\n       not\r\n       only improve heart function, but also help in bringing down blood pressure, and cholesterol levels in the body. A\r\n       mere 30 minutes stroll daily does good for the heart, if not much. It is recommended that sprinting is more\r\n       beneficial for the heart, than jogging.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Reduce Oil&lt;/h5&gt;\r\n\r\n    &lt;p&gt;The next tip is about keeping oil from your diet. Although, you cannot avoid oil completely,\r\n       you can keep its consumption to a small amount. Oils are a storehouse of calories and contain\r\n       little nutrition. As they mostly comprise fat, they have all chances to lead to the\r\n       development of plaque in the arteries thus, giving rise to some nasty heart problems. However,\r\n       not all types of oil are unhealthy. Fish oil contains omega-3 fatty acids, which not only help\r\n       in preventing cardiovascular diseases, but also reduce instances of heart attack. According to\r\n       a study published in the Journal of the American College of Cardiology, a group of patients\r\n       with cardiovascular disease had 30% less likelihood of heart attack because of omega-3 fatty\r\n       acids. Best sources include salmon, mackerel and herring. Flaxseed, walnuts, and soybeans are\r\n       also good sources.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Cut the Smoke&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If you think you cannot shun the habit of smoking, then you might as well know that you\r\n       cannot do anything good for your heart. One of the most severe risks of smoking relates to\r\n       heart diseases in almost every smoker. Quit smoking, and you have done half the job in\r\n       keeping your heart healthy!&lt;/p&gt;\r\n    &lt;h5&gt;Lose Weight&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If your figure is slim, and belly\r\n       flat, then you may have less things\r\n       to worry about heart diseases. I am\r\n       talking about weight loss. Being\r\n       overweight puts extra load on the\r\n       heart thus, increases the risk of\r\n       heart conditions. So, consume less\r\n       sugary foods and more of fiber and\r\n       complex carbohydrates, and fruits and\r\n       vegetables. Maintaining a healthy\r\n       weight is one of the basic\r\n       necessities for a healthy heart\r\n       today.&lt;/p&gt;\r\n    &lt;h5&gt;Add More Fiber&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        Fiber exists in two major groups; soluble (dissolves in water) and insoluble (does not dissolve in water).\r\n        Although\r\n        both the types are beneficial to health, it is the former type that does way better to reduce cholesterol levels\r\n        in\r\n        the body. Due to its soluble nature, it binds with the cholesterol in the intestines thus, keep it from being\r\n        absorbed. This keeps the level of LDL and total cholesterol down, while not affecting the HDL cholesterol level\r\n        in\r\n        any way. All a healthy person requires is a serving of 5 to 10 grams or more of soluble fiber in a day to avail\r\n        this\r\n        benefit of low cholesterol. Foods rich in this fiber include apples, peas, kidney beans, prunes, etc.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Beware of Saturated Fats&lt;/h5&gt;\r\n\r\n    &lt;p&gt;It is important that you limit the amount of saturated and trans fats you consume\r\n       from your food. These spike cholesterol levels in the body thus, increasing the risk\r\n       of coronary artery disease. So avoid or limit consumption of food such as red meat,\r\n       dairy products, coconut oil, palm oil. These are rich in saturated fatty acids. To\r\n       avoid trans fats, eat less of fast foods, bakery products, snacks, crackers, and\r\n       margarines. Go for foods rich in healthy fats such as polyunsaturated and\r\n       monounsaturated fats.&lt;/p&gt;\r\n    &lt;h5&gt;Eat Less Salt&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Sodium is good for the body, but\r\n       in petty amounts. High salt intake\r\n       means high blood pressure, which\r\n       eventually points out to heart\r\n       conditions. When sodium starts\r\n       accumulating in the blood, it\r\n       attracts water which in turn,\r\n       increases the blood volume. Now to\r\n       keep this blood circulating\r\n       through the blood vessels, the\r\n       heart has to work harder thus,\r\n       causing high blood pressure. The\r\n       recommended amount of sodium in\r\n       the food per day must be less than\r\n       2300 milligrams.&lt;/p&gt;\r\n    &lt;h5&gt;Take the\r\n        Right\r\n        Medication&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        In most cases, heart diseases are also related to the use of drugs. So, it is important that you take medicines\r\n        as\r\n        prescribed by the doctors, or get them altered if necessary.&lt;/p&gt;&lt;h5&gt;Moderate Alcohol&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Drinking alcohol in moderate amounts does not harm the body. In fact, some studies show that moderate consumption\r\n       provides some benefits for the heart. However, the habit of drinking is analogous to walking on thin ice. It is\r\n       not\r\n       difficult for any one to step out of his limit, and become a heavy drinker. So, ensure that either you stick to\r\n       moderate drinking or you don\'t drink at all.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Manage Stress&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Stress has also been known to be one of the common culprits of heart problems. Any stressful\r\n       situation elevates blood pressure and this response takes its toll on the heart. So, keep\r\n       yourself relaxed by practicing meditation, yoga, and other relaxation techniques.&lt;/p&gt;\r\n\r\n    &lt;p&gt;\r\n        To conclude, make a note of the above methods, and keep them handy in case you find it difficult to recall them.\r\n        And\r\n        now I would like to take your leave, as I have some sprinting to do! Take care!&lt;/p&gt;  ', '  ', ''),
(381, 1, 3, ' Establishing Your Brand on College Campuses   ', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students\' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now!\r\nSocial media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;\r\n&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;   ', '   ', ''),
(380, 1, 2, 'Establishing Your Brand on College Campuses   ', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students\' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now!\r\nSocial media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;\r\n&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;   ', '   ', ''),
(376, 2, 2, 'Believe in the Business of Your Dreams   ', '&lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won\'t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can\'t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don\'t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;   ', '   ', ''),
(368, 4, 2, 'Beautiful Rumi Quotes that are Worth Reading  ', '&lt;p&gt;Rumi, is the most popular Sufi poet in the world. His work is not only deep and intense, but also very ethereal. His poetry often stirs an emotion never touched and shows a facet never seen. This Buzzle article has a collection of some beautiful Rumi quotes that are worth reading, without which, life would literally feel quite disregarded.&lt;/p&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;As you start to walk on the way, the way appears.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Let yourself be silently drawn by the strange pull of what you really love. It will not lead you astray.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Two there are who are never satisfied -- the lover of the world and the lover of knowledge.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;What you seek is seeking you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t be satisfied with stories, how things have gone with others. Unfold your own myth.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Raise your words, not voice. It is rain that grows flowers, not thunder.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;You are not a drop in the ocean. You are the entire ocean in a drop.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Do you know what you are? You are a manuscript oƒ a divine letter. You are a mirror reflecting a noble face. This universe is not outside of you. Look inside yourself; everything that you want, you are already that.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t grieve. Anything you lose comes round in another form.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.&quot;\r\n&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Stop acting so small. You are the universe in ecstatic motion.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Forget safety. Live where you fear to live. Destroy your reputation. Be notorious.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Start a huge, foolish project, like Noah...it makes absolutely no difference what people think of you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;When you go through a hard period, when everything seems to oppose you, ... When you feel you cannot even bear one more minute, NEVER GIVE UP! Because it is the time and place that the course will divert!&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n\r\n  ', '  ', ''),
(364, 5, 2, 'How to Keep Your Heart Healthy  ', '&lt;p&gt;So how to keep your heart healthy? With so many heart diseases on the rise, most health-conscious people strive\r\n       to\r\n       seek the answer to this question. This article attempts to help you find the answer.&lt;/p&gt;\r\n    &lt;h5&gt;Go Green&lt;/h5&gt;\r\n\r\n    &lt;p&gt;When we speak of heart, we cannot miss out on the importance and benefits of plant foods. Vegetables are an\r\n       excellent source of glutamic acid. It is a class of amino acid which helps keeping blood pressure at lower\r\n       levels; safe levels, so to say. What\'s more? Veggies lack cholesterol, fat and even calories, which otherwise\r\n       tend to be the common culprits for causing heart diseases. Not to mention, the amount of vitamins and minerals\r\n       that vegetables provide to the body do the most for health.\r\n\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Be Active&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Without the aid of daily exercise, maintaining a good overall health is just more than a daunting task. Exercises\r\n       not\r\n       only improve heart function, but also help in bringing down blood pressure, and cholesterol levels in the body. A\r\n       mere 30 minutes stroll daily does good for the heart, if not much. It is recommended that sprinting is more\r\n       beneficial for the heart, than jogging.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Reduce Oil&lt;/h5&gt;\r\n\r\n    &lt;p&gt;The next tip is about keeping oil from your diet. Although, you cannot avoid oil completely,\r\n       you can keep its consumption to a small amount. Oils are a storehouse of calories and contain\r\n       little nutrition. As they mostly comprise fat, they have all chances to lead to the\r\n       development of plaque in the arteries thus, giving rise to some nasty heart problems. However,\r\n       not all types of oil are unhealthy. Fish oil contains omega-3 fatty acids, which not only help\r\n       in preventing cardiovascular diseases, but also reduce instances of heart attack. According to\r\n       a study published in the Journal of the American College of Cardiology, a group of patients\r\n       with cardiovascular disease had 30% less likelihood of heart attack because of omega-3 fatty\r\n       acids. Best sources include salmon, mackerel and herring. Flaxseed, walnuts, and soybeans are\r\n       also good sources.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Cut the Smoke&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If you think you cannot shun the habit of smoking, then you might as well know that you\r\n       cannot do anything good for your heart. One of the most severe risks of smoking relates to\r\n       heart diseases in almost every smoker. Quit smoking, and you have done half the job in\r\n       keeping your heart healthy!&lt;/p&gt;\r\n    &lt;h5&gt;Lose Weight&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If your figure is slim, and belly\r\n       flat, then you may have less things\r\n       to worry about heart diseases. I am\r\n       talking about weight loss. Being\r\n       overweight puts extra load on the\r\n       heart thus, increases the risk of\r\n       heart conditions. So, consume less\r\n       sugary foods and more of fiber and\r\n       complex carbohydrates, and fruits and\r\n       vegetables. Maintaining a healthy\r\n       weight is one of the basic\r\n       necessities for a healthy heart\r\n       today.&lt;/p&gt;\r\n    &lt;h5&gt;Add More Fiber&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        Fiber exists in two major groups; soluble (dissolves in water) and insoluble (does not dissolve in water).\r\n        Although\r\n        both the types are beneficial to health, it is the former type that does way better to reduce cholesterol levels\r\n        in\r\n        the body. Due to its soluble nature, it binds with the cholesterol in the intestines thus, keep it from being\r\n        absorbed. This keeps the level of LDL and total cholesterol down, while not affecting the HDL cholesterol level\r\n        in\r\n        any way. All a healthy person requires is a serving of 5 to 10 grams or more of soluble fiber in a day to avail\r\n        this\r\n        benefit of low cholesterol. Foods rich in this fiber include apples, peas, kidney beans, prunes, etc.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Beware of Saturated Fats&lt;/h5&gt;\r\n\r\n    &lt;p&gt;It is important that you limit the amount of saturated and trans fats you consume\r\n       from your food. These spike cholesterol levels in the body thus, increasing the risk\r\n       of coronary artery disease. So avoid or limit consumption of food such as red meat,\r\n       dairy products, coconut oil, palm oil. These are rich in saturated fatty acids. To\r\n       avoid trans fats, eat less of fast foods, bakery products, snacks, crackers, and\r\n       margarines. Go for foods rich in healthy fats such as polyunsaturated and\r\n       monounsaturated fats.&lt;/p&gt;\r\n    &lt;h5&gt;Eat Less Salt&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Sodium is good for the body, but\r\n       in petty amounts. High salt intake\r\n       means high blood pressure, which\r\n       eventually points out to heart\r\n       conditions. When sodium starts\r\n       accumulating in the blood, it\r\n       attracts water which in turn,\r\n       increases the blood volume. Now to\r\n       keep this blood circulating\r\n       through the blood vessels, the\r\n       heart has to work harder thus,\r\n       causing high blood pressure. The\r\n       recommended amount of sodium in\r\n       the food per day must be less than\r\n       2300 milligrams.&lt;/p&gt;\r\n    &lt;h5&gt;Take the\r\n        Right\r\n        Medication&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        In most cases, heart diseases are also related to the use of drugs. So, it is important that you take medicines\r\n        as\r\n        prescribed by the doctors, or get them altered if necessary.&lt;/p&gt;&lt;h5&gt;Moderate Alcohol&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Drinking alcohol in moderate amounts does not harm the body. In fact, some studies show that moderate consumption\r\n       provides some benefits for the heart. However, the habit of drinking is analogous to walking on thin ice. It is\r\n       not\r\n       difficult for any one to step out of his limit, and become a heavy drinker. So, ensure that either you stick to\r\n       moderate drinking or you don\'t drink at all.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Manage Stress&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Stress has also been known to be one of the common culprits of heart problems. Any stressful\r\n       situation elevates blood pressure and this response takes its toll on the heart. So, keep\r\n       yourself relaxed by practicing meditation, yoga, and other relaxation techniques.&lt;/p&gt;\r\n\r\n    &lt;p&gt;\r\n        To conclude, make a note of the above methods, and keep them handy in case you find it difficult to recall them.\r\n        And\r\n        now I would like to take your leave, as I have some sprinting to do! Take care!&lt;/p&gt;  ', '  ', ''),
(379, 1, 1, 'Establishing Your Brand on College Campuses   ', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students\' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now!\r\nSocial media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;\r\n&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;   ', '   ', ''),
(375, 2, 1, 'Believe in the Business of Your Dreams   ', '&lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won\'t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can\'t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don\'t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;   ', '   ', ''),
(371, 3, 1, 'Impact - The Heart of Business  ', '&lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;  ', '  ', '');
INSERT INTO `oc_simple_blog_article_description` (`simple_blog_article_description_id`, `simple_blog_article_id`, `language_id`, `article_title`, `description`, `meta_description`, `meta_keyword`) VALUES
(367, 4, 1, 'Beautiful Rumi Quotes that are Worth Reading  ', '&lt;p&gt;Rumi, is the most popular Sufi poet in the world. His work is not only deep and intense, but also very ethereal. His poetry often stirs an emotion never touched and shows a facet never seen. This Buzzle article has a collection of some beautiful Rumi quotes that are worth reading, without which, life would literally feel quite disregarded.&lt;/p&gt;\r\n\r\n&lt;blockquote&gt;&lt;p&gt;&quot;As you start to walk on the way, the way appears.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Let yourself be silently drawn by the strange pull of what you really love. It will not lead you astray.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Two there are who are never satisfied -- the lover of the world and the lover of knowledge.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;What you seek is seeking you.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t be satisfied with stories, how things have gone with others. Unfold your own myth.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Raise your words, not voice. It is rain that grows flowers, not thunder.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;You are not a drop in the ocean. You are the entire ocean in a drop.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Do you know what you are? You are a manuscript oƒ a divine letter. You are a mirror reflecting a noble face. This universe is not outside of you. Look inside yourself; everything that you want, you are already that.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t grieve. Anything you lose comes round in another form.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.&quot;\r\n&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Stop acting so small. You are the universe in ecstatic motion.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Forget safety. Live where you fear to live. Destroy your reputation. Be notorious.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Start a huge, foolish project, like Noah...it makes absolutely no difference what people think of you.&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;When you go through a hard period, when everything seems to oppose you, ... When you feel you cannot even bear one more minute, NEVER GIVE UP! Because it is the time and place that the course will divert!&quot;&lt;/p&gt;\r\n&lt;/blockquote&gt;  ', '  ', ''),
(363, 5, 1, 'How to Keep Your Heart Healthy  ', '&lt;p&gt;So how to keep your heart healthy? With so many heart diseases on the rise, most health-conscious people strive\r\n       to\r\n       seek the answer to this question. This article attempts to help you find the answer.&lt;/p&gt;\r\n    &lt;h5&gt;Go Green&lt;/h5&gt;\r\n\r\n    &lt;p&gt;When we speak of heart, we cannot miss out on the importance and benefits of plant foods. Vegetables are an\r\n       excellent source of glutamic acid. It is a class of amino acid which helps keeping blood pressure at lower\r\n       levels; safe levels, so to say. What\'s more? Veggies lack cholesterol, fat and even calories, which otherwise\r\n       tend to be the common culprits for causing heart diseases. Not to mention, the amount of vitamins and minerals\r\n       that vegetables provide to the body do the most for health.\r\n\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Be Active&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Without the aid of daily exercise, maintaining a good overall health is just more than a daunting task. Exercises\r\n       not\r\n       only improve heart function, but also help in bringing down blood pressure, and cholesterol levels in the body. A\r\n       mere 30 minutes stroll daily does good for the heart, if not much. It is recommended that sprinting is more\r\n       beneficial for the heart, than jogging.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Reduce Oil&lt;/h5&gt;\r\n\r\n    &lt;p&gt;The next tip is about keeping oil from your diet. Although, you cannot avoid oil completely,\r\n       you can keep its consumption to a small amount. Oils are a storehouse of calories and contain\r\n       little nutrition. As they mostly comprise fat, they have all chances to lead to the\r\n       development of plaque in the arteries thus, giving rise to some nasty heart problems. However,\r\n       not all types of oil are unhealthy. Fish oil contains omega-3 fatty acids, which not only help\r\n       in preventing cardiovascular diseases, but also reduce instances of heart attack. According to\r\n       a study published in the Journal of the American College of Cardiology, a group of patients\r\n       with cardiovascular disease had 30% less likelihood of heart attack because of omega-3 fatty\r\n       acids. Best sources include salmon, mackerel and herring. Flaxseed, walnuts, and soybeans are\r\n       also good sources.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Cut the Smoke&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If you think you cannot shun the habit of smoking, then you might as well know that you\r\n       cannot do anything good for your heart. One of the most severe risks of smoking relates to\r\n       heart diseases in almost every smoker. Quit smoking, and you have done half the job in\r\n       keeping your heart healthy!&lt;/p&gt;\r\n    &lt;h5&gt;Lose Weight&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If your figure is slim, and belly\r\n       flat, then you may have less things\r\n       to worry about heart diseases. I am\r\n       talking about weight loss. Being\r\n       overweight puts extra load on the\r\n       heart thus, increases the risk of\r\n       heart conditions. So, consume less\r\n       sugary foods and more of fiber and\r\n       complex carbohydrates, and fruits and\r\n       vegetables. Maintaining a healthy\r\n       weight is one of the basic\r\n       necessities for a healthy heart\r\n       today.&lt;/p&gt;\r\n    &lt;h5&gt;Add More Fiber&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        Fiber exists in two major groups; soluble (dissolves in water) and insoluble (does not dissolve in water).\r\n        Although\r\n        both the types are beneficial to health, it is the former type that does way better to reduce cholesterol levels\r\n        in\r\n        the body. Due to its soluble nature, it binds with the cholesterol in the intestines thus, keep it from being\r\n        absorbed. This keeps the level of LDL and total cholesterol down, while not affecting the HDL cholesterol level\r\n        in\r\n        any way. All a healthy person requires is a serving of 5 to 10 grams or more of soluble fiber in a day to avail\r\n        this\r\n        benefit of low cholesterol. Foods rich in this fiber include apples, peas, kidney beans, prunes, etc.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Beware of Saturated Fats&lt;/h5&gt;\r\n\r\n    &lt;p&gt;It is important that you limit the amount of saturated and trans fats you consume\r\n       from your food. These spike cholesterol levels in the body thus, increasing the risk\r\n       of coronary artery disease. So avoid or limit consumption of food such as red meat,\r\n       dairy products, coconut oil, palm oil. These are rich in saturated fatty acids. To\r\n       avoid trans fats, eat less of fast foods, bakery products, snacks, crackers, and\r\n       margarines. Go for foods rich in healthy fats such as polyunsaturated and\r\n       monounsaturated fats.&lt;/p&gt;\r\n    &lt;h5&gt;Eat Less Salt&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Sodium is good for the body, but\r\n       in petty amounts. High salt intake\r\n       means high blood pressure, which\r\n       eventually points out to heart\r\n       conditions. When sodium starts\r\n       accumulating in the blood, it\r\n       attracts water which in turn,\r\n       increases the blood volume. Now to\r\n       keep this blood circulating\r\n       through the blood vessels, the\r\n       heart has to work harder thus,\r\n       causing high blood pressure. The\r\n       recommended amount of sodium in\r\n       the food per day must be less than\r\n       2300 milligrams.&lt;/p&gt;\r\n    &lt;h5&gt;Take the\r\n        Right\r\n        Medication&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        In most cases, heart diseases are also related to the use of drugs. So, it is important that you take medicines\r\n        as\r\n        prescribed by the doctors, or get them altered if necessary.&lt;/p&gt;&lt;h5&gt;Moderate Alcohol&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Drinking alcohol in moderate amounts does not harm the body. In fact, some studies show that moderate consumption\r\n       provides some benefits for the heart. However, the habit of drinking is analogous to walking on thin ice. It is\r\n       not\r\n       difficult for any one to step out of his limit, and become a heavy drinker. So, ensure that either you stick to\r\n       moderate drinking or you don\'t drink at all.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Manage Stress&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Stress has also been known to be one of the common culprits of heart problems. Any stressful\r\n       situation elevates blood pressure and this response takes its toll on the heart. So, keep\r\n       yourself relaxed by practicing meditation, yoga, and other relaxation techniques.&lt;/p&gt;\r\n\r\n    &lt;p&gt;\r\n        To conclude, make a note of the above methods, and keep them handy in case you find it difficult to recall them.\r\n        And\r\n        now I would like to take your leave, as I have some sprinting to do! Take care!&lt;/p&gt;  ', '  ', ''),
(359, 6, 1, 'Four Types of Verbal Communication  ', '&lt;p&gt;Verbal communication include sounds, words, language, and speech. Speaking is an effective way of communicating\r\n       and helps in expressing our emotions in words. This form of communication is further classified into four types,\r\n       which are:\r\n    &lt;/p&gt;\r\n    &lt;ol&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Intrapersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication is extremely private and restricted to ourselves. It includes the silent\r\n               conversations we have with ourselves, wherein we juggle roles between the sender and receiver who are\r\n               processing our thoughts and actions. This process of communication when analyzed can either be conveyed\r\n               verbally to someone or stay confined as thoughts.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Interpersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication takes place between two individuals and is thus a one-on-one conversation.\r\n               Here, the two individuals involved will swap their roles of sender and receiver in order to communicate\r\n               in a clearer manner.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Small Group Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication can take place only when there are more than two people involved. Here the\r\n               number of people will be small enough to allow each participant to interact and converse with the rest.\r\n               Press conferences, board meetings, and team meetings are examples of group communication. Unless a\r\n               specific issue is being discussed, small group discussions can become chaotic and difficult to interpret\r\n               by everybody. This lag in understanding information completely can result in miscommunication.\r\n            &lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Public Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication takes place when one individual addresses a large gathering of people.\r\n               Election campaigns and public speeches are example of this type of communication. In such cases, there is\r\n               usually a single sender of information and several receivers who are being addressed.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n    &lt;/ol&gt;  ', '  ', ''),
(355, 7, 1, 'Proper color solutions for the office  ', '&lt;p&gt;When it comes to remodeling an office, one of the most important aspects is painting. Any shade of paint can\r\n       change the complete look of a room as a color has an ability to change a drab and boring room into a stunning\r\n       one. Many people prefer to paint their homes in serene colors as it relaxes the mind. There are many hues of\r\n       colors to choose from that match the atmosphere of a room.&lt;/p&gt;\r\n\r\n    &lt;p&gt;An office is a place where many people come and go. Choose some paint colors that will stimulate the employees,\r\n       relax the customers and make them feel welcome. Here are some ideas for interior paint colors and combinations to\r\n       remodel your office and make it look more appealing to the vision.&lt;/p&gt;\r\n\r\n    &lt;p&gt;Avoid using white, as this color gives a very sterile look to the walls. Remember a shade of color can make a\r\n       room look large or small. So, it is better to avoid black or dark colors that will give off a repulsive look to\r\n       your office.&lt;/p&gt;\r\n\r\n    &lt;p&gt;The popular choice of paint colors that will give a soothing and inviting look to your office are beige, tan,\r\n       light yellow and some shades of blue.&lt;/p&gt;\r\n\r\n    &lt;p&gt;When you choose paint colors for your office make sure that these colors have a resemblance to the flooring and\r\n       office furniture.&lt;/p&gt;\r\n\r\n    &lt;p&gt;These were some tips for choosing paint colors. Before you paint the walls of the room, always paint a small\r\n       portion of the wall to check how it looks. If you are satisfied with the result, you can go ahead with the task,\r\n       or else you can always try other combinations. Whatever color you choose, make sure that it serves its purpose\r\n       and brightens up the atmosphere of the room. Happy painting!&lt;/p&gt;  ', '  ', ''),
(397, 10, 4, '7 Extraordinary experiences in South America', '&lt;p&gt;Delivering great travel commodities since 1970\'s our company is still alive and kicking – as you can see now we are online to meet you here and satisfy your needs in the best way we can and even better than that! We know how important is to build strong and reliable relationships with the client.&lt;/p&gt;\r\n&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;', '    ', ''),
(396, 10, 2, '7 Extraordinary experiences in South America', '&lt;p&gt;Delivering great travel commodities since 1970\'s our company is still alive and kicking – as you can see now we are online to meet you here and satisfy your needs in the best way we can and even better than that! We know how important is to build strong and reliable relationships with the client.&lt;/p&gt;\r\n&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;', '           ', ''),
(401, 9, 4, 'Five ways to save money when you travel', '&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;\r\n&lt;p&gt;We are always glad to welcome you at hospitable pages of or online shop or if you are in the area – don\'t be shy and show yourself!&lt;/p&gt;', '   ', ''),
(400, 9, 2, 'Five ways to save money when you travel', '&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;\r\n&lt;p&gt;We are always glad to welcome you at hospitable pages of or online shop or if you are in the area – don\'t be shy and show yourself!&lt;/p&gt;', '                   ', ''),
(405, 8, 4, 'What to buy in the summer sales', '&lt;p&gt;We all love coming back from the sales and going through all our bargain buys, but back away from splurging and instead invest only in a few essentials.&lt;/p&gt;\r\n&lt;p&gt;An increasing number of people now want to do their part to save the planet due to the worsening problems caused by global warming. Unfortunately, numerous people assume that going green is costly and time consuming. Read on to discover several immediate things you can do to get on the path to living green.&lt;/p&gt;\r\n&lt;p&gt;Recycling is the top way to start. A lot of people continue to place glass and aluminum items in their normal garbage even though recycling is not that hard to do today. In the US, it\'s not hard to locate a trash service that offers glass and aluminum recycling choices. Many people still continue to discard these items even though recycling bins are not hard to find. It merely takes a few minutes to wash off the cans and bottles before placing them into the recycle bin.&lt;/p&gt;', '   ', ''),
(395, 10, 1, '7 Extraordinary experiences in South America', '&lt;p&gt;Delivering great travel commodities since 1970\'s our company is still alive and kicking – as you can see now we are online to meet you here and satisfy your needs in the best way we can and even better than that! We know how important is to build strong and reliable relationships with the client.&lt;/p&gt;\r\n&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;', '           ', ''),
(399, 9, 1, 'Five ways to save money when you travel', '&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;\r\n&lt;p&gt;We are always glad to welcome you at hospitable pages of or online shop or if you are in the area – don\'t be shy and show yourself!&lt;/p&gt;', '                   ', ''),
(404, 8, 2, 'What to buy in the summer sales', '&lt;p&gt;We all love coming back from the sales and going through all our bargain buys, but back away from splurging and instead invest only in a few essentials.&lt;/p&gt;\r\n&lt;p&gt;An increasing number of people now want to do their part to save the planet due to the worsening problems caused by global warming. Unfortunately, numerous people assume that going green is costly and time consuming. Read on to discover several immediate things you can do to get on the path to living green.&lt;/p&gt;\r\n&lt;p&gt;Recycling is the top way to start. A lot of people continue to place glass and aluminum items in their normal garbage even though recycling is not that hard to do today. In the US, it\'s not hard to locate a trash service that offers glass and aluminum recycling choices. Many people still continue to discard these items even though recycling bins are not hard to find. It merely takes a few minutes to wash off the cans and bottles before placing them into the recycle bin.&lt;/p&gt;', '        ', ''),
(358, 7, 4, ' Proper color solutions for the office', '&lt;p&gt;When it comes to remodeling an office, one of the most important aspects is painting. Any shade of paint can\r\n       change the complete look of a room as a color has an ability to change a drab and boring room into a stunning\r\n       one. Many people prefer to paint their homes in serene colors as it relaxes the mind. There are many hues of\r\n       colors to choose from that match the atmosphere of a room.&lt;/p&gt;\r\n\r\n    &lt;p&gt;An office is a place where many people come and go. Choose some paint colors that will stimulate the employees,\r\n       relax the customers and make them feel welcome. Here are some ideas for interior paint colors and combinations to\r\n       remodel your office and make it look more appealing to the vision.&lt;/p&gt;\r\n\r\n    &lt;p&gt;Avoid using white, as this color gives a very sterile look to the walls. Remember a shade of color can make a\r\n       room look large or small. So, it is better to avoid black or dark colors that will give off a repulsive look to\r\n       your office.&lt;/p&gt;\r\n\r\n    &lt;p&gt;The popular choice of paint colors that will give a soothing and inviting look to your office are beige, tan,\r\n       light yellow and some shades of blue.&lt;/p&gt;\r\n\r\n    &lt;p&gt;When you choose paint colors for your office make sure that these colors have a resemblance to the flooring and\r\n       office furniture.&lt;/p&gt;\r\n\r\n    &lt;p&gt;These were some tips for choosing paint colors. Before you paint the walls of the room, always paint a small\r\n       portion of the wall to check how it looks. If you are satisfied with the result, you can go ahead with the task,\r\n       or else you can always try other combinations. Whatever color you choose, make sure that it serves its purpose\r\n       and brightens up the atmosphere of the room. Happy painting!&lt;/p&gt;  ', ' ', ''),
(362, 6, 4, ' Four Types of Verbal Communication', '&lt;p&gt;Verbal communication include sounds, words, language, and speech. Speaking is an effective way of communicating\r\n       and helps in expressing our emotions in words. This form of communication is further classified into four types,\r\n       which are:\r\n    &lt;/p&gt;\r\n    &lt;ol&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Intrapersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication is extremely private and restricted to ourselves. It includes the silent\r\n               conversations we have with ourselves, wherein we juggle roles between the sender and receiver who are\r\n               processing our thoughts and actions. This process of communication when analyzed can either be conveyed\r\n               verbally to someone or stay confined as thoughts.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Interpersonal Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This form of communication takes place between two individuals and is thus a one-on-one conversation.\r\n               Here, the two individuals involved will swap their roles of sender and receiver in order to communicate\r\n               in a clearer manner.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Small Group Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication can take place only when there are more than two people involved. Here the\r\n               number of people will be small enough to allow each participant to interact and converse with the rest.\r\n               Press conferences, board meetings, and team meetings are examples of group communication. Unless a\r\n               specific issue is being discussed, small group discussions can become chaotic and difficult to interpret\r\n               by everybody. This lag in understanding information completely can result in miscommunication.\r\n            &lt;/p&gt;\r\n        &lt;/li&gt;\r\n        &lt;li&gt;\r\n            &lt;h5&gt;Public Communication&lt;/h5&gt;\r\n\r\n            &lt;p&gt;This type of communication takes place when one individual addresses a large gathering of people.\r\n               Election campaigns and public speeches are example of this type of communication. In such cases, there is\r\n               usually a single sender of information and several receivers who are being addressed.&lt;/p&gt;\r\n        &lt;/li&gt;\r\n    &lt;/ol&gt;  ', ' ', ''),
(366, 5, 4, ' How to Keep Your Heart Healthy  ', '&lt;p&gt;So how to keep your heart healthy? With so many heart diseases on the rise, most health-conscious people strive\r\n       to\r\n       seek the answer to this question. This article attempts to help you find the answer.&lt;/p&gt;\r\n    &lt;h5&gt;Go Green&lt;/h5&gt;\r\n\r\n    &lt;p&gt;When we speak of heart, we cannot miss out on the importance and benefits of plant foods. Vegetables are an\r\n       excellent source of glutamic acid. It is a class of amino acid which helps keeping blood pressure at lower\r\n       levels; safe levels, so to say. What\'s more? Veggies lack cholesterol, fat and even calories, which otherwise\r\n       tend to be the common culprits for causing heart diseases. Not to mention, the amount of vitamins and minerals\r\n       that vegetables provide to the body do the most for health.\r\n\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Be Active&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Without the aid of daily exercise, maintaining a good overall health is just more than a daunting task. Exercises\r\n       not\r\n       only improve heart function, but also help in bringing down blood pressure, and cholesterol levels in the body. A\r\n       mere 30 minutes stroll daily does good for the heart, if not much. It is recommended that sprinting is more\r\n       beneficial for the heart, than jogging.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Reduce Oil&lt;/h5&gt;\r\n\r\n    &lt;p&gt;The next tip is about keeping oil from your diet. Although, you cannot avoid oil completely,\r\n       you can keep its consumption to a small amount. Oils are a storehouse of calories and contain\r\n       little nutrition. As they mostly comprise fat, they have all chances to lead to the\r\n       development of plaque in the arteries thus, giving rise to some nasty heart problems. However,\r\n       not all types of oil are unhealthy. Fish oil contains omega-3 fatty acids, which not only help\r\n       in preventing cardiovascular diseases, but also reduce instances of heart attack. According to\r\n       a study published in the Journal of the American College of Cardiology, a group of patients\r\n       with cardiovascular disease had 30% less likelihood of heart attack because of omega-3 fatty\r\n       acids. Best sources include salmon, mackerel and herring. Flaxseed, walnuts, and soybeans are\r\n       also good sources.\r\n    &lt;/p&gt;\r\n    &lt;h5&gt;Cut the Smoke&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If you think you cannot shun the habit of smoking, then you might as well know that you\r\n       cannot do anything good for your heart. One of the most severe risks of smoking relates to\r\n       heart diseases in almost every smoker. Quit smoking, and you have done half the job in\r\n       keeping your heart healthy!&lt;/p&gt;\r\n    &lt;h5&gt;Lose Weight&lt;/h5&gt;\r\n\r\n    &lt;p&gt;If your figure is slim, and belly\r\n       flat, then you may have less things\r\n       to worry about heart diseases. I am\r\n       talking about weight loss. Being\r\n       overweight puts extra load on the\r\n       heart thus, increases the risk of\r\n       heart conditions. So, consume less\r\n       sugary foods and more of fiber and\r\n       complex carbohydrates, and fruits and\r\n       vegetables. Maintaining a healthy\r\n       weight is one of the basic\r\n       necessities for a healthy heart\r\n       today.&lt;/p&gt;\r\n    &lt;h5&gt;Add More Fiber&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        Fiber exists in two major groups; soluble (dissolves in water) and insoluble (does not dissolve in water).\r\n        Although\r\n        both the types are beneficial to health, it is the former type that does way better to reduce cholesterol levels\r\n        in\r\n        the body. Due to its soluble nature, it binds with the cholesterol in the intestines thus, keep it from being\r\n        absorbed. This keeps the level of LDL and total cholesterol down, while not affecting the HDL cholesterol level\r\n        in\r\n        any way. All a healthy person requires is a serving of 5 to 10 grams or more of soluble fiber in a day to avail\r\n        this\r\n        benefit of low cholesterol. Foods rich in this fiber include apples, peas, kidney beans, prunes, etc.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Beware of Saturated Fats&lt;/h5&gt;\r\n\r\n    &lt;p&gt;It is important that you limit the amount of saturated and trans fats you consume\r\n       from your food. These spike cholesterol levels in the body thus, increasing the risk\r\n       of coronary artery disease. So avoid or limit consumption of food such as red meat,\r\n       dairy products, coconut oil, palm oil. These are rich in saturated fatty acids. To\r\n       avoid trans fats, eat less of fast foods, bakery products, snacks, crackers, and\r\n       margarines. Go for foods rich in healthy fats such as polyunsaturated and\r\n       monounsaturated fats.&lt;/p&gt;\r\n    &lt;h5&gt;Eat Less Salt&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Sodium is good for the body, but\r\n       in petty amounts. High salt intake\r\n       means high blood pressure, which\r\n       eventually points out to heart\r\n       conditions. When sodium starts\r\n       accumulating in the blood, it\r\n       attracts water which in turn,\r\n       increases the blood volume. Now to\r\n       keep this blood circulating\r\n       through the blood vessels, the\r\n       heart has to work harder thus,\r\n       causing high blood pressure. The\r\n       recommended amount of sodium in\r\n       the food per day must be less than\r\n       2300 milligrams.&lt;/p&gt;\r\n    &lt;h5&gt;Take the\r\n        Right\r\n        Medication&lt;/h5&gt;\r\n\r\n    &lt;p&gt;\r\n        In most cases, heart diseases are also related to the use of drugs. So, it is important that you take medicines\r\n        as\r\n        prescribed by the doctors, or get them altered if necessary.&lt;/p&gt;&lt;h5&gt;Moderate Alcohol&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Drinking alcohol in moderate amounts does not harm the body. In fact, some studies show that moderate consumption\r\n       provides some benefits for the heart. However, the habit of drinking is analogous to walking on thin ice. It is\r\n       not\r\n       difficult for any one to step out of his limit, and become a heavy drinker. So, ensure that either you stick to\r\n       moderate drinking or you don\'t drink at all.&lt;/p&gt;\r\n    &lt;h5&gt;\r\n        Manage Stress&lt;/h5&gt;\r\n\r\n    &lt;p&gt;Stress has also been known to be one of the common culprits of heart problems. Any stressful\r\n       situation elevates blood pressure and this response takes its toll on the heart. So, keep\r\n       yourself relaxed by practicing meditation, yoga, and other relaxation techniques.&lt;/p&gt;\r\n\r\n    &lt;p&gt;\r\n        To conclude, make a note of the above methods, and keep them handy in case you find it difficult to recall them.\r\n        And\r\n        now I would like to take your leave, as I have some sprinting to do! Take care!&lt;/p&gt;  ', ' ', ''),
(370, 4, 4, ' Beautiful Rumi Quotes that are Worth Reading', '&lt;p&gt;Rumi, is the most popular Sufi poet in the world. His work is not only deep and intense, but also very ethereal. His poetry often stirs an emotion never touched and shows a facet never seen. This Buzzle article has a collection of some beautiful Rumi quotes that are worth reading, without which, life would literally feel quite disregarded.&lt;/p&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;As you start to walk on the way, the way appears.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Let yourself be silently drawn by the strange pull of what you really love. It will not lead you astray.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Two there are who are never satisfied -- the lover of the world and the lover of knowledge.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;What you seek is seeking you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t be satisfied with stories, how things have gone with others. Unfold your own myth.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Raise your words, not voice. It is rain that grows flowers, not thunder.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;You are not a drop in the ocean. You are the entire ocean in a drop.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Do you know what you are? You are a manuscript oƒ a divine letter. You are a mirror reflecting a noble face. This universe is not outside of you. Look inside yourself; everything that you want, you are already that.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Don\'t grieve. Anything you lose comes round in another form.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Yesterday I was clever, so I wanted to change the world. Today I am wise, so I am changing myself.&quot;\r\n&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Stop acting so small. You are the universe in ecstatic motion.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Forget safety. Live where you fear to live. Destroy your reputation. Be notorious.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;Start a huge, foolish project, like Noah...it makes absolutely no difference what people think of you.&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n&lt;blockquote&gt;&lt;p&gt;&quot;When you go through a hard period, when everything seems to oppose you, ... When you feel you cannot even bear one more minute, NEVER GIVE UP! Because it is the time and place that the course will divert!&quot;&lt;/p&gt;&lt;/blockquote&gt;\r\n\r\n  ', ' ', ''),
(374, 3, 4, ' Impact - The Heart of Business', '&lt;p&gt;Thousands of people dream of having their own business and even more so be a successful entrepreneur. But what does it take to achieve success in the business industry?&lt;/p&gt;\r\n\r\n&lt;p&gt;One of the most successful entrepreneurs featured at the Forbes website, Wendy Lipton - Dibner said that &quot;the success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot;.\r\nShe shared her success story at the Forbes website and said that when she was young she learned a very important business objective from her high school activity and that is to go out, explore, come back and explain how money is made in business. This is an objective she never forgot until she made millions for herself.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;When she was already very successful, she never stopped understanding business and how it really works. Profit is the number one goal in business and how you make it is a natural talent. Yes, there may be a lot of guidelines given and showed on television and the internet but only you know how you will make your sales to the top.\r\n&lt;/p&gt;\r\n&lt;p&gt;Try to ponder on these notes when thinking of a business:\r\n&lt;/p&gt;\r\n\r\n&lt;ol&gt;\r\n&lt;li&gt;Passion. Business may be set on profit but the core of your business should be something you love. Passion counts a lot in businesses because it also builds your determination in achieving your goal.&lt;/li&gt;\r\n&lt;li&gt; Impact. Business is a big and competitive world, what will matter is how you make a difference to your market. How your business will impact your market. The profit of your business will rely on the impact of your business. The mark it will leave to your customers will make it grow.&lt;/li&gt;\r\n&lt;li&gt;Three Guidelines.&lt;/li&gt;\r\n&lt;/ol&gt;\r\n&lt;p&gt;If you have noticed, the three guidelines below are very simple and natural.&lt;/p&gt;  ', ' ', ''),
(378, 2, 4, ' Believe in the Business of Your Dreams', '&lt;p&gt;What is stopping you from believing in the business of your dreams? Insecurity? Fear? Lack of confidence? All of the above? How can you overcome these obstructions?&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Your Mantras&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;You may be wondering if you have the necessary skills, time, connections, and a million other things in order to create the business of your dreams. If you let your uncertainty and insecurity overpower you, you won\'t ever be able to unleash your true business potential. To unlock the positive forces of your creativity and drive that will yield amazing results, make these your mantras:\r\n&quot;I will abandon all negative thoughts that prevent me from realizing my business objectives.&quot;\r\n&quot;I will focus my energy on growing the business of my dreams.&quot;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;A Dreamer and a Doer&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;It is important to take time to develop your vision; and your practical thinking should be geared to this vision. You need to work with conviction. Being a dreamer does not mean that you can\'t also be a doer. In fact, having a dream is the starting point for building your dream business. The problem starts when you stop there instead of setting realizable immediate targets. Success cannot come from one day to the next. So you need to build your dream business bit by bit. When your dreams begin to be transformed into reality thanks to your actions, you become aware of the power you possess for catalyzing success; and this further strengthens your determination to reach every single one of your business goals.&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Make It Happen&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Nothing can happen without tenacity, fortitude, and courage. Be bold enough to make choices; don\'t just let things happen to you. Though you cannot have control over everything, you can focus on what you can handle and influence with your actions in a given situation. You have the power to make decisions that will move your business forward. You should not feel daunted by your lack of knowledge of business strategies either. You learn and grow while building your business. No women entrepreneur/mompreneur possesses absolute knowledge; there are so many examples of hugely successful businesswomen who started out without having any clue about business promotion techniques. Their motivation to learn, their unwavering belief that they could create the business of their dreams, and their steadfastness were key factors for their success.\r\n&lt;/p&gt;   ', ' ', ''),
(382, 1, 4, ' Establishing Your Brand on College Campuses', '&lt;p&gt;Many students are cash-strapped, nowadays. Nevertheless, their purchasing power is very high. Research reveals that 20 million students in the US have a combined disposable income of $417 billion. Moreover, another survey of students\' parents reveals that students now make 70 percent of their purchases themselves. These purchases are often made on credit cards. Therefore, students often have a significantly higher purchasing power.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you know this, you can utilize it to capture the attention of the 16-24 age demographic. However, it is essential for your product or service to appeal to the lifestyle of the students. Additionally, student ambassadors should be utilized to spread the word about your product or service to their friends and classmates.&lt;/p&gt;\r\n\r\n\r\n&lt;p&gt;If you have not yet considered this demographic, it is time to reach out to them now!\r\nSocial media is a popular method for socialization and communication between many young people. Students are the majority users of social networking sites like Facebook and Twitter. These are the right places to introduce brands to young people.It is probably the right place to introduce a brand to them. To capture the student audience, it is essential to be a part of the conversation; it is also important to keep them engaged. Social media is the ideal platform for this.&lt;/p&gt;\r\n&lt;p&gt;However, studies state that half of these social media savvy youngsters fail to follow brands on social networking sites. Students who do follow often only show temporary, marginal support. Social media is definitely a great platform for engaging students and spreading the word. However, it is definitely not the best for brand introduction and recognition.&lt;/p&gt;   ', ' ', ''),
(403, 8, 1, 'What to buy in the summer sales', '&lt;p&gt;We all love coming back from the sales and going through all our bargain buys, but back away from splurging and instead invest only in a few essentials.&lt;/p&gt;\r\n&lt;p&gt;An increasing number of people now want to do their part to save the planet due to the worsening problems caused by global warming. Unfortunately, numerous people assume that going green is costly and time consuming. Read on to discover several immediate things you can do to get on the path to living green.&lt;/p&gt;\r\n&lt;p&gt;Recycling is the top way to start. A lot of people continue to place glass and aluminum items in their normal garbage even though recycling is not that hard to do today. In the US, it\'s not hard to locate a trash service that offers glass and aluminum recycling choices. Many people still continue to discard these items even though recycling bins are not hard to find. It merely takes a few minutes to wash off the cans and bottles before placing them into the recycle bin.&lt;/p&gt;', '        ', ''),
(398, 10, 3, '7 Extraordinary experiences in South America', '&lt;p&gt;Delivering great travel commodities since 1970\'s our company is still alive and kicking – as you can see now we are online to meet you here and satisfy your needs in the best way we can and even better than that! We know how important is to build strong and reliable relationships with the client.&lt;/p&gt;\r\n&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;', '           ', ''),
(402, 9, 3, 'Five ways to save money when you travel', '&lt;p&gt;You may be sure that by visiting our online or outdoor shop you\'ll find here everything you need for your future journey and no matter what it would be - a ski holiday, festival or rock-climbing tour - we\'ve got tons of goods that will save your time, money and efforts. Our shop is a one-stop destination for those people who appreciate travel commodities of only a premium quality.&lt;/p&gt;\r\n&lt;p&gt;We are always glad to welcome you at hospitable pages of or online shop or if you are in the area – don\'t be shy and show yourself!&lt;/p&gt;', '                   ', ''),
(406, 8, 3, 'What to buy in the summer sales', '&lt;p&gt;We all love coming back from the sales and going through all our bargain buys, but back away from splurging and instead invest only in a few essentials.&lt;/p&gt;\r\n&lt;p&gt;An increasing number of people now want to do their part to save the planet due to the worsening problems caused by global warming. Unfortunately, numerous people assume that going green is costly and time consuming. Read on to discover several immediate things you can do to get on the path to living green.&lt;/p&gt;\r\n&lt;p&gt;Recycling is the top way to start. A lot of people continue to place glass and aluminum items in their normal garbage even though recycling is not that hard to do today. In the US, it\'s not hard to locate a trash service that offers glass and aluminum recycling choices. Many people still continue to discard these items even though recycling bins are not hard to find. It merely takes a few minutes to wash off the cans and bottles before placing them into the recycle bin.&lt;/p&gt;', '        ', '');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_description_additional`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_description_additional`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_description_additional` (
  `simple_blog_article_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `additional_description` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_product_related`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_product_related`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_product_related` (
  `simple_blog_article_id` int(16) NOT NULL,
  `product_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_article_product_related`
--

INSERT INTO `oc_simple_blog_article_product_related` (`simple_blog_article_id`, `product_id`) VALUES
(9, 29),
(9, 28);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_to_category`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_to_category`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_category` (
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_category_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_article_to_category`
--

INSERT INTO `oc_simple_blog_article_to_category` (`simple_blog_article_id`, `simple_blog_category_id`) VALUES
(2, 2),
(4, 4),
(4, 2),
(6, 2),
(6, 1),
(3, 2),
(7, 4),
(7, 3),
(8, 4),
(8, 1),
(9, 4),
(9, 2),
(9, 1),
(5, 2),
(5, 3),
(1, 1),
(10, 2),
(10, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_to_layout`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_to_layout`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_layout` (
  `simple_blog_article_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL,
  `layout_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_article_to_store`
--

DROP TABLE IF EXISTS `oc_simple_blog_article_to_store`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_article_to_store` (
  `simple_blog_article_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_article_to_store`
--

INSERT INTO `oc_simple_blog_article_to_store` (`simple_blog_article_id`, `store_id`) VALUES
(2, 0),
(4, 0),
(6, 0),
(3, 0),
(7, 0),
(8, 0),
(9, 0),
(5, 0),
(1, 0),
(10, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_author`
--

DROP TABLE IF EXISTS `oc_simple_blog_author`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_author` (
  `simple_blog_author_id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `image` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_author_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_author`
--

INSERT INTO `oc_simple_blog_author` (`simple_blog_author_id`, `name`, `image`, `status`, `date_added`, `date_modified`) VALUES
(1, 'Jessica Prinston', 'catalog/avatar.jpg', 1, '2015-09-16 17:26:04', '2017-10-19 18:42:26'),
(2, 'Sam Kromstain', 'catalog/avatar.jpg', 1, '2015-09-17 10:26:40', '2017-10-19 18:42:57'),
(3, 'Robert Johnson', 'catalog/avatar.jpg', 1, '2015-09-21 16:32:38', '2017-10-19 18:42:43'),
(4, 'Edna Barton', 'catalog/avatar.jpg', 1, '2015-09-21 16:34:45', '2017-10-19 18:42:10');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_author_description`
--

DROP TABLE IF EXISTS `oc_simple_blog_author_description`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_author_description` (
  `simple_blog_author_description_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_author_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `description` mediumtext NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_author_description_id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_author_description`
--

INSERT INTO `oc_simple_blog_author_description` (`simple_blog_author_description_id`, `simple_blog_author_id`, `language_id`, `description`, `meta_description`, `meta_keyword`, `date_added`) VALUES
(50, 1, 2, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(49, 1, 1, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(56, 2, 2, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store. &lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(55, 2, 1, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store. &lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(53, 3, 2, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(52, 3, 1, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(47, 4, 2, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;/p&gt;', '  ', '  ', '0000-00-00 00:00:00'),
(46, 4, 1, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;/p&gt;', '  ', '  ', '0000-00-00 00:00:00'),
(48, 4, 3, '&lt;p&gt;Quality control manager. Her mission is to check the products we ship and settle quality issues if any.&lt;/p&gt;', '  ', '  ', '0000-00-00 00:00:00'),
(51, 1, 3, '&lt;p&gt;Mega positive shop assistant always ready to help you make the right choice and charm you with a smile.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(54, 3, 3, '&lt;p&gt;Senior salesman with 15 years of experience. He knows everything about the products he offers.&lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00'),
(57, 2, 3, '&lt;p&gt;Wholesale manager. Contact him if you want to buy a batch of the products offered at our store. &lt;/p&gt;', ' ', ' ', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_category`
--

DROP TABLE IF EXISTS `oc_simple_blog_category`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_category` (
  `simple_blog_category_id` int(16) NOT NULL AUTO_INCREMENT,
  `image` mediumtext NOT NULL,
  `parent_id` int(16) NOT NULL,
  `top` tinyint(1) NOT NULL,
  `blog_category_column` int(16) NOT NULL,
  `column` int(8) NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_category`
--

INSERT INTO `oc_simple_blog_category` (`simple_blog_category_id`, `image`, `parent_id`, `top`, `blog_category_column`, `column`, `sort_order`, `status`, `date_added`, `date_modified`) VALUES
(1, '', 0, 1, 0, 3, 0, 1, '2015-09-16 17:23:22', '2017-11-23 14:43:27'),
(2, 'catalog/products/product-1.png', 0, 1, 0, 5, 2, 1, '2015-09-17 10:24:12', '2017-11-23 14:43:56'),
(3, '', 0, 1, 0, 5, 1, 1, '2015-09-21 16:44:25', '2017-11-23 14:44:15'),
(4, '', 0, 1, 0, 5, 3, 1, '2015-09-28 17:06:19', '2017-11-23 14:44:07');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_category_description`
--

DROP TABLE IF EXISTS `oc_simple_blog_category_description`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_description` (
  `simple_blog_category_description_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_category_id` int(16) NOT NULL,
  `language_id` int(16) NOT NULL,
  `name` varchar(256) NOT NULL,
  `description` mediumtext NOT NULL,
  `meta_description` varchar(256) NOT NULL,
  `meta_keyword` varchar(256) NOT NULL,
  PRIMARY KEY (`simple_blog_category_description_id`)
) ENGINE=MyISAM AUTO_INCREMENT=118 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_category_description`
--

INSERT INTO `oc_simple_blog_category_description` (`simple_blog_category_description_id`, `simple_blog_category_id`, `language_id`, `name`, `description`, `meta_description`, `meta_keyword`) VALUES
(111, 4, 2, 'Management  ', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '  ', ''),
(95, 1, 2, 'Branding     ', '', '     ', ''),
(115, 3, 2, 'Consulting    ', '', '    ', ''),
(107, 2, 2, 'Customer Service   ', '', '   ', ''),
(110, 4, 1, 'Management  ', '&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '  ', ''),
(94, 1, 1, 'Branding     ', '', '     ', ''),
(116, 3, 3, 'Consulting    ', '', '    ', ''),
(96, 1, 3, 'Branding     ', '', '     ', ''),
(97, 1, 4, 'Branding', '', ' ', ''),
(106, 2, 1, 'Customer Service   ', '', '   ', ''),
(114, 3, 1, 'Consulting    ', '&lt;br&gt;', '    ', ''),
(108, 2, 3, ' Customer Service   ', '', '   ', ''),
(109, 2, 4, 'Customer Service ', '', '  ', ''),
(112, 4, 3, ' Management  ', '', '  ', ''),
(113, 4, 4, ' Management', '', ' ', ''),
(117, 3, 4, 'Consulting ', '', '  ', '');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_category_to_layout`
--

DROP TABLE IF EXISTS `oc_simple_blog_category_to_layout`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_to_layout` (
  `simple_blog_category_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL,
  `layout_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_category_to_store`
--

DROP TABLE IF EXISTS `oc_simple_blog_category_to_store`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_category_to_store` (
  `simple_blog_category_id` int(16) NOT NULL,
  `store_id` int(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_category_to_store`
--

INSERT INTO `oc_simple_blog_category_to_store` (`simple_blog_category_id`, `store_id`) VALUES
(2, 0),
(3, 0),
(1, 0),
(4, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_comment`
--

DROP TABLE IF EXISTS `oc_simple_blog_comment`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_comment` (
  `simple_blog_comment_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_article_reply_id` int(16) NOT NULL,
  `author` varchar(64) NOT NULL,
  `comment` mediumtext NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_comment`
--

INSERT INTO `oc_simple_blog_comment` (`simple_blog_comment_id`, `simple_blog_article_id`, `simple_blog_article_reply_id`, `author`, `comment`, `status`, `date_added`, `date_modified`) VALUES
(1, 1, 0, 'Bernard Show', 'That’s awesome! Future belongs to youngsters, so businessmen can’t ignore their needs in any case.', 1, '2015-09-17 10:05:35', '2015-09-28 17:18:32'),
(16, 2, 0, 'Max Harris', 'Will try to repeat your mantras every day. Hopefully they will help in my current project.', 1, '2015-09-28 17:20:59', '2015-09-28 17:20:59'),
(2, 3, 0, 'Zack Hernandez', 'The success of your business would solely depend on you. The only thing you can rely on is your power to achieve your goal&quot; – very true to life statement', 1, '2015-09-18 11:39:25', '2015-09-28 17:19:38'),
(3, 3, 0, 'James Anderson', ' I am thinking of starting my own business and will ponder on the author’s notes. Concise and understandable, good job.', 1, '2015-09-18 11:48:36', '2015-09-28 17:20:05'),
(15, 2, 0, 'Taylor Miller', 'Follow your dream and it will turn to reality. A very inspiring article. Thanks for sharing!', 1, '2015-09-28 17:20:34', '2015-09-28 17:20:34'),
(4, 3, 0, 'Greg Wilson', 'Unbelievable… Three simple guidelines to follow that can change your life. Worth trying out, sure they will work as everything genius is simple.', 1, '2015-09-18 12:08:42', '2015-09-28 17:19:53'),
(6, 1, 0, 'Michael Ventura', 'Completely agree with the author. Modern businessmen should involve young people, introduce brands to them, socialize… Looks like a fresh product market!', 1, '2015-09-21 18:18:56', '2015-09-28 17:18:47'),
(14, 1, 1, 'Sarah Cole', 'The author did a great job with all these research work. Really valuable information, thank you!', 1, '2015-09-28 17:18:32', '2015-09-28 17:18:32'),
(17, 2, 0, 'Sidney Garcia', 'I thought I am just a dreamer, but now I know how to become a doer. That’s cool, appreciate it!', 1, '2015-09-28 17:21:18', '2015-09-28 17:21:18'),
(18, 4, 0, 'Joe Lee', 'Very inspiring! So much wisdom in simple words…', 1, '2015-10-13 12:37:35', '2015-10-13 14:27:08'),
(19, 4, 0, 'Kate Taylor', 'Love this poet! Absolutely brilliant quotes!', 1, '2015-10-13 12:37:45', '2015-10-13 14:27:02'),
(20, 4, 0, 'Kim Martin', 'He is phenomenal! Rumi is considered to be the most popular poet in America.', 1, '2015-10-13 12:37:54', '2015-10-13 14:26:57'),
(21, 5, 0, 'Rob Gonzalez', 'Thanks for your pieces of advice. Will try to stick to them.', 1, '2015-10-13 12:56:02', '2015-10-13 14:26:52'),
(22, 5, 0, 'Paul Young', 'Gosh! I have been slowly damaging my heart all these years! It’s time to stop ruining myself.', 1, '2015-10-13 12:56:12', '2015-10-13 14:26:47'),
(23, 5, 0, 'Sandy Hill', 'Human life is the most precious thing in this world. It’s really time to stop committing lazy suicides.', 1, '2015-10-13 12:56:22', '2015-10-13 14:26:41'),
(24, 6, 0, 'Libi Ramirez', 'Communication is the process of exchanging information in the form of messages, symbols, thoughts, signs, and opinions. It’s utterly important for such social beings like people', 1, '2015-10-13 13:01:26', '2015-10-13 14:26:35'),
(25, 6, 0, 'Kirsten Evans', 'Indeed, it would be extremely hard to imagine a world without some form of interpersonal interaction.', 1, '2015-10-13 13:01:32', '2015-10-13 14:26:30'),
(26, 6, 0, 'Brook Murphy', 'Some of the basic ways by which we communicate with one another is through speech, sign language, body language, touch, and eye contact. So, waiting for the sequel of your post.\r\n', 1, '2015-10-13 13:01:40', '2015-10-13 14:26:25'),
(27, 7, 0, 'Ashley Cooper', 'Now I know what colors to choose for me office, thank you!', 1, '2015-10-13 13:05:32', '2015-10-13 14:26:21'),
(28, 7, 0, 'Gomez Bell', 'The repairing does not seem that challenging any more. Great tips!', 1, '2015-10-13 13:05:39', '2015-10-13 14:26:16'),
(29, 7, 0, 'Morgan Cook', 'Colors that stimulate the employees, relax the customers and make them feel welcome… Cool! That’s a dream!', 1, '2015-10-13 13:05:45', '2015-10-13 14:26:10'),
(30, 8, 0, 'Nancy Long', 'Thanks for sharing! Will try to avoid the listed mistakes.', 1, '2015-10-13 14:16:59', '2015-10-13 14:26:06'),
(31, 8, 0, 'Eva Reed', 'I wish I’ve read this article earlier… Useful tips for all young managers.', 1, '2015-10-13 14:17:05', '2015-10-13 14:23:53'),
(32, 8, 0, 'Betty Butler', 'Just got my new position. The discussed matter is really urgent for me.', 1, '2015-10-13 14:17:14', '2015-10-13 14:23:48'),
(33, 9, 0, 'Melany Wood', 'Smile, the depression will think you are an idiot and go away', 1, '2015-10-13 14:22:47', '2015-10-13 14:23:26'),
(34, 9, 0, 'York Cruz', 'BTW, your smiling face looks much more appealing and beautiful too.', 1, '2015-10-13 14:22:56', '2015-10-13 14:23:20'),
(35, 9, 0, 'Vivien Foster', 'I like to spread my laughter around as it\'s contagious', 1, '2015-10-13 14:23:05', '2015-10-13 14:23:16'),
(36, 10, 0, 'Mark Jenkins', 'You’ve raised an important topic. Hopefully many people will at least consider shifting to green life.', 1, '2015-10-13 15:31:41', '2016-08-11 18:43:36'),
(37, 10, 0, 'Dudley Diaz', 'Going green turned out to be really simple. Let’s go green, guys!', 1, '2015-10-13 15:31:51', '2015-10-13 15:32:13'),
(38, 10, 0, 'Meril Ward', 'Preserving our planet for future generation is a necessity. So, go green now while it’s not too late.\r\n', 1, '2015-10-13 15:31:58', '2015-10-13 15:32:08');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_related_article`
--

DROP TABLE IF EXISTS `oc_simple_blog_related_article`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_related_article` (
  `simple_blog_related_article_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_article_id` int(16) NOT NULL,
  `simple_blog_article_related_id` int(16) NOT NULL,
  `sort_order` int(8) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `date_added` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_related_article_id`)
) ENGINE=MyISAM AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_related_article`
--

INSERT INTO `oc_simple_blog_related_article` (`simple_blog_related_article_id`, `simple_blog_article_id`, `simple_blog_article_related_id`, `sort_order`, `status`, `date_added`) VALUES
(70, 2, 1, 0, 1, '2017-11-23 12:51:51'),
(67, 4, 1, 0, 1, '2017-11-23 12:51:17'),
(69, 3, 2, 1, 1, '2017-11-23 12:51:32'),
(68, 3, 1, 2, 1, '2017-11-23 12:51:32'),
(71, 1, 7, 0, 1, '2017-11-23 12:52:08'),
(73, 9, 3, 0, 1, '2018-03-01 15:11:11');

-- --------------------------------------------------------

--
-- Структура таблицы `oc_simple_blog_view`
--

DROP TABLE IF EXISTS `oc_simple_blog_view`;
CREATE TABLE IF NOT EXISTS `oc_simple_blog_view` (
  `simple_blog_view_id` int(16) NOT NULL AUTO_INCREMENT,
  `simple_blog_article_id` int(16) NOT NULL,
  `view` int(16) NOT NULL,
  `date_added` datetime NOT NULL,
  `date_modified` datetime NOT NULL,
  PRIMARY KEY (`simple_blog_view_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `oc_simple_blog_view`
--

INSERT INTO `oc_simple_blog_view` (`simple_blog_view_id`, `simple_blog_article_id`, `view`, `date_added`, `date_modified`) VALUES
(1, 1, 94, '2015-09-16 18:15:21', '2017-11-23 19:26:49'),
(2, 3, 189, '2015-09-17 10:28:27', '2016-04-15 15:57:10'),
(3, 2, 7, '2015-09-21 16:08:28', '2016-03-16 16:47:17'),
(10, 6, 17, '2015-09-29 10:44:23', '2017-10-03 18:31:05'),
(5, 7, 24, '2015-09-21 17:30:47', '2017-11-15 11:27:29'),
(6, 5, 25, '2015-09-21 17:53:05', '2017-08-23 17:21:55'),
(7, 8, 63, '2015-09-22 12:42:49', '2018-10-12 16:46:46'),
(8, 4, 12, '2015-09-23 17:59:14', '2016-03-16 16:42:28'),
(9, 9, 89, '2015-09-25 17:55:16', '2018-03-07 12:08:14'),
(11, 10, 75, '2015-10-13 15:31:30', '2017-12-27 19:25:51');
COMMIT;
