<?php
// Heading
$_['heading_title']    = 'Cпискок желаний ZEMEZ';

// Text
$_['text_module']      = 'Модули';
$_['text_extension']      = 'Модули';
$_['text_success']     = 'Успех: вы изменили модуль Списка желаний';
$_['text_edit']        = 'Редактировать модуль Списка желаний Zemez';

// Entry
$_['entry_name']       = 'Имя модуля';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Предупреждение: у вас нет разрешения на изменение модуля Списка желаний Zemez!';
$_['error_name']       = 'Имя модуля должно быть от 3 до 64 символов!';