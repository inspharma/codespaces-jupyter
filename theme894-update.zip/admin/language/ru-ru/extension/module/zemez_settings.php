<?php
// Heading
$_['heading_title']    = 'ZEMEZ Settings';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Успех: вы модифицировали модуль Zemez Settings!';
$_['text_edit']        = 'Редактировать модуль Zemez Settings';

// Entry
$_['entry_name']       = 'Имя модуля';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Предупреждение: у вас нет разрешения на модификацию модуля Zemez Settings!';
$_['error_name']       = 'Имя модуля должно быть от 3 до 64 символов!';