<?php
$_['d_export_import_setting'] = array(
    'limit' => '',
    'limit_step' => 50,
    'truncate_table' => 0
);