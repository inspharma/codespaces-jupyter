<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'محرر اللغات';

// Text
$_['text_edit']        = 'تحرير';
$_['text_list']        = 'قائمة';
$_['text_translation'] = 'اختيار الترجمة';
$_['text_translation'] = 'الترجمة';

// Column
$_['column_flag']      = 'العلم';
$_['column_country']   = 'الدولة';
$_['column_progress']  = 'حالة الترجمة';
$_['column_action']    = 'تحرير';

// button
$_['button_install']   = 'تثبيت';
$_['button_uninstall'] = 'الغاء التثبيت';
$_['button_refresh']   = 'تحديث';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
