<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']                = 'لوحة التحكم';

// Error
$_['error_install']                = 'تحذير: لم يتم حذف مجلد التنصيب - ويجب حذفه لأمان المتجر!';
