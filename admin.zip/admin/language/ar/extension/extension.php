<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']  = 'الاضافات';

// Text
$_['text_success']   = 'تم التعديل !';
$_['text_list']      = 'قائمة';
$_['text_type']      = 'اختيار نوع الاضافة';
$_['text_filter']    = 'فلتر';
$_['text_analytics'] = 'تحلايلات';
$_['text_captcha']   = 'تحقق كابتشا';
$_['text_dashboard'] = 'لوحة التحكم';
$_['text_feed']      = 'تغذية المنتجات';
$_['text_fraud']     = 'مكافحة الاختراق';
$_['text_module']    = 'الموديولات';
$_['text_content']   = 'محتوى الموديولات';
$_['text_menu']      = 'قائمة الموديولات';
$_['text_payment']   = 'طرق الدفع';
$_['text_shipping']  = 'طرق الشحن';
$_['text_theme']     = 'القوالب';
$_['text_total']     = 'اجماليات الطلب';
