<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']     = 'الاحداث';

// Text
$_['text_success']      = 'تم التعديل !';
$_['text_list']         = 'قائمة';
$_['text_event']        = 'يتم استخدام الاحداث بواسطة اضافات تتجاوز الدوال الافتراضية للمتجر. اذا واجهتك اي مشكلة مع الاحداث يمكنك تشغيلها وتعطيلها من هنا.';

// Column
$_['column_code']       = 'رمز الحدث';
$_['column_trigger']    = 'المشغل';
$_['column_action']     = 'تحرير';
$_['column_status']     = 'الحالة';
$_['column_date_added'] = 'تاريخ البداية';
$_['column_action']     = 'تحرير';

// Error
$_['error_permission']  = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
