<?php
/**
 * @version		$Id: ebay_listing.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Language Translation German Frontend
 * @author		mic - https://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']	= 'Im eBay-Store';