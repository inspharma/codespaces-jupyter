<?php
/**
 * @version		$Id: not_found.php 4989 2017-06-22 09:22:42Z mic $
 * @package		Translation Deutsch
 * @author		mic - http://osworx.net
 * @copyright	2017 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']	= 'Seite nicht gefunden';

// Text
$_['text_error']	= 'Trotz aller Anstrengungen kann die angeforderte Seite leider nicht gefunden werden.<br />Sollte das Problem weiterhin bestehen bitte uns kontaktieren - vielen Dank.';