<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'الصفحة المطلوبة لا يمكن العثور عليها !';

// Text
$_['text_error']    = 'الصفحة المطلوبة لا يمكن العثور عليها !';