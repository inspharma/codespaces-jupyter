<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'جاري أعمال الصيانة';

// Text
$_['text_maintenance'] = 'جاري أعمال الصيانة';
$_['text_message']     = '<h1 style="text-align:center;">نحن نقوم حالياً بأعمال الصيانة الدورية. <br/>وستكون العودة في أقرب وقت ممكن. الرجاء العودة قريباً.</h1>';