<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_home']          = 'الرئيسية';
$_['text_wishlist']      = 'قائمة رغباتي (%s)';
$_['text_shopping_cart'] = 'سلة الشراء';
$_['text_category']      = 'أقسام الموقع';
$_['text_account']       = 'حسابي';
$_['text_register']      = 'تسجيل جديد';
$_['text_login']         = 'تسجيل الدخول';
$_['text_order']         = 'طلباتي';
$_['text_transaction']   = 'رصيدي';
$_['text_download']      = 'ملفات التنزيل';
$_['text_logout']        = 'خروج';
$_['text_checkout']      = 'إنهاء الطلب';
$_['text_search']        = 'بحث';
$_['text_all']           = 'اذهب الى قسم';
$_['open_text']          = '24/7 خدمة العملاء';