<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_title']       = 'شحن مجاني';
$_['text_description'] = 'شحن مجاني';