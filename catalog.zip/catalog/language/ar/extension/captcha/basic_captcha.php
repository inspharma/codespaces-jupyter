<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_captcha'] = 'التحقق';

// Entry
$_['entry_captcha'] = 'ادخل رمز التحقق كما في الصورة أدناه';

// Error
$_['error_captcha'] = 'رمز التحقق لا يتطابق مع الصورة !';
