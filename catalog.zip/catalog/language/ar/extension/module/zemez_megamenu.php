<?php
// Heading
$_['heading_menu_title'] = 'الاقسام';