<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title'] = 'العروض المميزة';

// Text
$_['text_tax']      = 'السعر بدون الضريبة:';