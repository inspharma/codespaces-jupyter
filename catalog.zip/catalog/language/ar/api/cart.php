<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_success']     = 'تم تعديل محتويات سلة الشراء !';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات الدخول الى واجهة برمجة - API!';
$_['error_stock']      = 'المنتجات التي عليها علامة *** غير متوفر الكمية!';
$_['error_minimum']    = 'الحد الأدنى لقيمة الطلب %s هي %s!';
$_['error_store']      = 'لم يتم العثور على المنتج في المتجر الذي تم اختياره !';
$_['error_required']   = '%s مطلوب !';